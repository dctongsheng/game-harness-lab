using System.Buffers.Binary;
using System.IO.Pipes;
using System.Text;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace BetterGenshinImpact.AgentBridge;

public static class AgentPipeProtocol
{
    public const int MaxPayloadBytes = 16 * 1024 * 1024;

    public static async Task<JObject> ReadAsync(Stream stream, CancellationToken cancellationToken)
    {
        var header = new byte[4];
        await stream.ReadExactlyAsync(header, cancellationToken).ConfigureAwait(false);
        var count = BinaryPrimitives.ReadInt32LittleEndian(header);
        if (count is <= 0 or > MaxPayloadBytes) throw new InvalidDataException("Invalid agent frame length.");
        var payload = new byte[count];
        await stream.ReadExactlyAsync(payload, cancellationToken).ConfigureAwait(false);
        return JObject.Parse(new UTF8Encoding(false, true).GetString(payload));
    }

    public static async Task WriteAsync(Stream stream, JObject payload, CancellationToken cancellationToken)
    {
        var raw = Encoding.UTF8.GetBytes(payload.ToString(Formatting.None));
        if (raw.Length is <= 0 or > MaxPayloadBytes) throw new InvalidDataException("Invalid agent frame length.");
        var header = new byte[4];
        BinaryPrimitives.WriteInt32LittleEndian(header, raw.Length);
        await stream.WriteAsync(header, cancellationToken).ConfigureAwait(false);
        await stream.WriteAsync(raw, cancellationToken).ConfigureAwait(false);
        await stream.FlushAsync(cancellationToken).ConfigureAwait(false);
    }
}

/// <summary>Per-user local IPC. A separate control pipe keeps stop independent of screenshots.</summary>
public sealed class AgentPipeServer(AgentCommandHost host, string name) : IAsyncDisposable
{
    private readonly CancellationTokenSource _lifetime = new();
    private readonly List<Task> _listeners = [];

    public void Start()
    {
        if (!System.Text.RegularExpressions.Regex.IsMatch(name, "^[a-zA-Z0-9_.-]{1,100}$"))
            throw new ArgumentException("Invalid agent pipe name.");
        if (_listeners.Count != 0) throw new InvalidOperationException("Agent pipes are already running.");
        // Multiple independent workers let status polling proceed during capture.
        for (var index = 0; index < 4; index++) _listeners.Add(ListenAsync(name, false));
        _listeners.Add(ListenAsync(name + ".control", true));
    }

    private async Task ListenAsync(string pipeName, bool controlOnly)
    {
        while (!_lifetime.IsCancellationRequested)
        {
            await using var pipe = new NamedPipeServerStream(pipeName, PipeDirection.InOut, 8,
                PipeTransmissionMode.Byte, PipeOptions.Asynchronous | PipeOptions.CurrentUserOnly);
            try
            {
                await pipe.WaitForConnectionAsync(_lifetime.Token).ConfigureAwait(false);
                using var timeout = CancellationTokenSource.CreateLinkedTokenSource(_lifetime.Token);
                timeout.CancelAfter(TimeSpan.FromSeconds(10));
                var request = await AgentPipeProtocol.ReadAsync(pipe, timeout.Token).ConfigureAwait(false);
                var identity = request.Value<string>("request_id");
                JObject response;
                try
                {
                    if (request.Value<int>("version") != 1 || string.IsNullOrWhiteSpace(identity))
                        throw new ArgumentException("Invalid agent envelope.");
                    var operation = request.Value<string>("operation");
                    if (controlOnly && operation != "stop") throw new ArgumentException("Control pipe accepts stop only.");
                    var data = request["data"] as JObject ?? new JObject();
                    JToken result;
                    switch (operation)
                    {
                        case "describe": result = host.Describe(); break;
                        case "arm": host.Arm(); result = new JObject(); break;
                        case "observe": result = await host.ObserveAsync(timeout.Token).ConfigureAwait(false); break;
                        case "candidates": result = host.Candidates(data.Value<long>("frame_id")); break;
                        case "start": result = await host.StartAsync(data, timeout.Token).ConfigureAwait(false); break;
                        case "reconcile": result = host.Reconcile(data.Value<string>("command_id") ?? ""); break;
                        case "cancel": result = host.Cancel(data.Value<string>("command_id") ?? ""); break;
                        case "stop": host.Stop(); result = new JObject(); break;
                        default: throw new ArgumentException("Unsupported agent operation.");
                    }
                    response = new JObject { ["version"] = 1, ["request_id"] = identity,
                                             ["success"] = true, ["data"] = result };
                }
                catch (Exception exception) when (exception is ArgumentException or InvalidOperationException
                                                   or JsonException or IOException)
                {
                    response = new JObject { ["version"] = 1, ["request_id"] = identity,
                                             ["success"] = false, ["error"] = exception.GetType().Name };
                }
                await AgentPipeProtocol.WriteAsync(pipe, response, timeout.Token).ConfigureAwait(false);
            }
            catch (Exception exception) when (exception is IOException or OperationCanceledException
                                               or JsonException or DecoderFallbackException)
            {
                // A bad/disconnected client does not terminate the listener.
            }
        }
    }

    public async ValueTask DisposeAsync()
    {
        _lifetime.Cancel();
        host.Stop();
        await Task.WhenAll(_listeners).ConfigureAwait(false);
        _lifetime.Dispose();
    }
}
