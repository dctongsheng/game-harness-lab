using System.Diagnostics;
using Newtonsoft.Json.Linq;

namespace BetterGenshinImpact.AgentBridge;

public sealed record GameObservation(JObject Scope, JObject Facts, string[] Images);
public sealed record SkillOutcome(string Status, string Reason, JObject Evidence);

public interface IAgentGameBackend
{
    Task<GameObservation> CaptureAsync(CancellationToken cancellationToken);
    Task<SkillOutcome> ExecuteAsync(JObject option, CancellationToken cancellationToken);
    void ReleaseInputs();
}

/// <summary>
/// Local authority for one input lease. No model request runs in this process.
/// Cached observations and full options are authoritative; client hashes are
/// audit references, never substitutes for host-side semantic validation.
/// </summary>
public sealed class AgentCommandHost : IAsyncDisposable
{
    private sealed record Frame(JObject Observation, JArray Options, long CapturedAt);
    private sealed class CommandState(JObject command)
    {
        internal JObject Command { get; } = (JObject)command.DeepClone();
        internal JObject Result { get; set; } = ResultFor(command.Value<string>("command_id")!, "running");
        internal long StartBy { get; set; }
    }

    private readonly object _gate = new();
    private readonly SemaphoreSlim _captureGate = new(1, 1);
    private readonly IAgentGameBackend _backend;
    private readonly JArray _options;
    private readonly JObject _metadata;
    private readonly Dictionary<long, Frame> _frames = new();
    private readonly Dictionary<string, CommandState> _commands = new(StringComparer.Ordinal);
    private readonly CancellationTokenSource _lifetime = new();
    private readonly Task _watchdog;
    private readonly TimeSpan _leaseTimeout;
    private readonly string _sessionId = Guid.NewGuid().ToString("N");
    private long _frameId;
    private long _generation;
    private long _lastContact = Stopwatch.GetTimestamp();
    private bool _halted = true;
    private bool _disposed;
    private bool _releaseFailed;
    private JObject? _scope;
    private CommandState? _active;
    private CancellationTokenSource? _activeCancellation;

    public AgentCommandHost(IAgentGameBackend backend, JArray options, TimeSpan? leaseTimeout = null, JObject? metadata = null)
    {
        _backend = backend;
        _options = (JArray)options.DeepClone();
        _metadata = (JObject)(metadata?.DeepClone() ?? new JObject());
        var ids = new HashSet<string>(StringComparer.Ordinal);
        foreach (var option in _options.Cast<JObject>())
        {
            if (string.IsNullOrWhiteSpace(option.Value<string>("id")) || !ids.Add(option.Value<string>("id")!)
                || option["preconditions"] is not JObject { Count: > 0 }
                || option.Value<int>("ttl_ms") is < 100 or > 30000
                || option.Value<int>("timeout_ms") is < 100 or > 300000)
                throw new ArgumentException("Invalid or duplicate agent option.", nameof(options));
        }
        _leaseTimeout = leaseTimeout ?? TimeSpan.FromSeconds(3);
        if (_leaseTimeout <= TimeSpan.Zero) throw new ArgumentOutOfRangeException(nameof(leaseTimeout));
        _watchdog = WatchdogAsync();
    }

    public JObject Describe() => (JObject)_metadata.DeepClone();

    public void Arm()
    {
        lock (_gate)
        {
            ObjectDisposedException.ThrowIf(_disposed, this);
            if (_releaseFailed) throw new InvalidOperationException("Input release failed; restart the execution host.");
            if (_active is not null) throw new InvalidOperationException("Previous skill is still stopping.");
            _halted = false;
            _generation++;
            _frames.Clear();
            _lastContact = Stopwatch.GetTimestamp();
        }
    }

    public async Task<JObject> ObserveAsync(CancellationToken cancellationToken)
    {
        await _captureGate.WaitAsync(cancellationToken).ConfigureAwait(false);
        try
        {
            var captured = await _backend.CaptureAsync(cancellationToken).ConfigureAwait(false);
            bool changed;
            lock (_gate) changed = _scope is not null && !JToken.DeepEquals(_scope, captured.Scope);
            if (changed) Stop();
            lock (_gate)
            {
                ObjectDisposedException.ThrowIf(_disposed, this);
                _scope = (JObject)captured.Scope.DeepClone();
                var observation = new JObject
                {
                    ["session_id"] = _sessionId, ["scope"] = _scope.DeepClone(),
                    ["frame_id"] = ++_frameId, ["control_generation"] = _generation,
                    ["facts"] = captured.Facts.DeepClone(), ["images"] = new JArray(captured.Images)
                };
                var options = _halted ? new JArray() : new JArray(_options.Cast<JObject>()
                    .Where(option => Available(option, captured.Facts)).Select(option => option.DeepClone()));
                _frames.Add(_frameId, new Frame((JObject)observation.DeepClone(), options, Stopwatch.GetTimestamp()));
                while (_frames.Count > 128) _frames.Remove(_frames.Keys.Min());
                if (_active is null) _lastContact = Stopwatch.GetTimestamp();
                return observation;
            }
        }
        finally { _captureGate.Release(); }
    }

    public JArray Candidates(long frameId)
    {
        lock (_gate)
        {
            if (_active is null) _lastContact = Stopwatch.GetTimestamp();
            if (!_frames.TryGetValue(frameId, out var frame)) throw new InvalidOperationException("Unknown frame.");
            return (JArray)frame.Options.DeepClone();
        }
    }

    public async Task<JObject> StartAsync(JObject command, CancellationToken cancellationToken)
    {
        var identity = command.Value<string>("command_id");
        if (string.IsNullOrWhiteSpace(identity) || identity.Length > 128)
            throw new ArgumentException("Invalid command ID.");
        lock (_gate)
        {
            if (_commands.TryGetValue(identity, out var existing))
            {
                if (!JToken.DeepEquals(existing.Command, command)) throw new ArgumentException("Command ID reused with a different payload.");
                _lastContact = Stopwatch.GetTimestamp();
                return (JObject)existing.Result.DeepClone();
            }
        }
        // Capture outside the command lock so a blocked screenshot cannot block stop.
        var current = await ObserveAsync(cancellationToken).ConfigureAwait(false);
        lock (_gate)
        {
            if (_commands.TryGetValue(identity, out var existing))
            {
                if (!JToken.DeepEquals(existing.Command, command)) throw new ArgumentException("Command ID reused with a different payload.");
                return (JObject)existing.Result.DeepClone();
            }
            ObjectDisposedException.ThrowIf(_disposed, this);
            if (_halted || _active is not null) return ResultFor(identity, "cancelled", "host_stopped_or_busy");
            if (_commands.Count >= 4096) throw new InvalidOperationException("Command ledger is full; restart the session.");
            if (command["source_frame_id"]?.Type != JTokenType.Integer
                || !_frames.TryGetValue(command.Value<long>("source_frame_id"), out var source)
                || command["control_generation"]?.Type != JTokenType.Integer
                || command.Value<long>("control_generation") != _generation
                || command.Value<string>("session_id") != _sessionId
                || !JToken.DeepEquals(command["scope"], current["scope"])
                || !JToken.DeepEquals(source.Observation["scope"], current["scope"])
                || source.Observation.Value<long>("control_generation") != _generation
                || command.Value<string>("origin") != "decision"
                || command.Value<string>("action_granularity") != "skill"
                || command["option"] is not JObject option)
                return ResultFor(identity, "cancelled", "stale_or_invalid_binding");
            var offered = source.Options.Cast<JObject>().SingleOrDefault(item => item.Value<string>("id") == option.Value<string>("id"));
            if (offered is null || !JToken.DeepEquals(offered, option)
                || !Available(option, (JObject)current["facts"]!))
                return ResultFor(identity, "cancelled", "action_semantics_or_preconditions_changed");
            var elapsed = Stopwatch.GetElapsedTime(source.CapturedAt).TotalMilliseconds;
            if (command["remaining_ttl_ms"]?.Type != JTokenType.Integer
                || command.Value<int>("remaining_ttl_ms") <= 0 || elapsed >= option.Value<int>("ttl_ms"))
                return ResultFor(identity, "cancelled", "expired");
            var now = Stopwatch.GetTimestamp();
            var state = new CommandState(command)
            {
                StartBy = Math.Min(source.CapturedAt + (long)(option.Value<int>("ttl_ms") * (double)Stopwatch.Frequency / 1000),
                    now + (long)(command.Value<int>("remaining_ttl_ms") * (double)Stopwatch.Frequency / 1000))
            };
            var cancellation = new CancellationTokenSource(option.Value<int>("timeout_ms"));
            _active = state;
            _activeCancellation = cancellation;
            _commands.Add(identity, state);
            _lastContact = Stopwatch.GetTimestamp();
            _ = Task.Run(() => ExecuteAsync(state, (JObject)option.DeepClone(), cancellation));
            return (JObject)state.Result.DeepClone();
        }
    }

    public JObject Reconcile(string commandId)
    {
        lock (_gate)
        {
            if (_active?.Command.Value<string>("command_id") == commandId)
                _lastContact = Stopwatch.GetTimestamp();
            return _commands.TryGetValue(commandId, out var state)
                ? (JObject)state.Result.DeepClone() : ResultFor(commandId, "unknown", "command_not_found");
        }
    }

    public JObject Cancel(string commandId)
    {
        bool active;
        lock (_gate) active = _active?.Command.Value<string>("command_id") == commandId;
        if (active) Stop();
        return Reconcile(commandId);
    }

    public void Stop()
    {
        CancellationTokenSource? cancellation;
        lock (_gate)
        {
            _halted = true;
            _generation++;
            _frames.Clear();
            cancellation = _activeCancellation;
        }
        try { cancellation?.Cancel(); }
        catch (ObjectDisposedException) { }
        finally { ReleaseInputs(); }
    }

    private async Task ExecuteAsync(CommandState state, JObject option, CancellationTokenSource cancellation)
    {
        using var releaseOnCancel = cancellation.Token.Register(ReleaseInputs);
        JObject result;
        try
        {
            cancellation.Token.ThrowIfCancellationRequested();
            if (Stopwatch.GetTimestamp() >= state.StartBy) throw new TimeoutException("Command expired before execution.");
            var outcome = await _backend.ExecuteAsync(option, cancellation.Token).ConfigureAwait(false);
            var status = cancellation.IsCancellationRequested ? "cancelled" : outcome.Status;
            if (status is not ("succeeded" or "failed" or "cancelled" or "unknown"))
                throw new InvalidOperationException("Backend returned a nonterminal outcome.");
            result = ResultFor(state.Command.Value<string>("command_id")!, status, outcome.Reason, outcome.Evidence);
        }
        catch (Exception exception)
        {
            result = ResultFor(state.Command.Value<string>("command_id")!,
                cancellation.IsCancellationRequested ? "cancelled" : "failed", exception.GetType().Name);
        }
        finally { ReleaseInputs(); }
        lock (_gate)
        {
            if (_releaseFailed)
                result = ResultFor(state.Command.Value<string>("command_id")!, "unknown", "input_release_failed");
            else if (_halted || state.Command.Value<long>("control_generation") != _generation)
                result = ResultFor(state.Command.Value<string>("command_id")!, "cancelled", "control_invalidated");
            state.Result = result;
            if (ReferenceEquals(_active, state))
            {
                _active = null;
                _activeCancellation = null;
            }
        }
        cancellation.Dispose();
    }

    private void ReleaseInputs()
    {
        try { _backend.ReleaseInputs(); }
        catch (Exception)
        {
            lock (_gate)
            {
                _halted = true;
                _generation++;
                _releaseFailed = true;
            }
        }
    }

    private async Task WatchdogAsync()
    {
        using var timer = new PeriodicTimer(TimeSpan.FromMilliseconds(100));
        try
        {
            while (await timer.WaitForNextTickAsync(_lifetime.Token).ConfigureAwait(false))
            {
                bool expired;
                lock (_gate) expired = _active is not null && !_halted
                    && Stopwatch.GetElapsedTime(_lastContact) > _leaseTimeout;
                if (expired) Stop();
            }
        }
        catch (OperationCanceledException) when (_lifetime.IsCancellationRequested) { }
    }

    private static bool Available(JObject option, JObject facts) =>
        ((JObject)option["preconditions"]!).Properties()
        .All(property => facts.TryGetValue(property.Name, out var value) && JToken.DeepEquals(value, property.Value));

    private static JObject ResultFor(string identity, string status, string reason = "", JObject? evidence = null) =>
        new() { ["command_id"] = identity, ["status"] = status, ["reason"] = reason,
                ["evidence"] = evidence?.DeepClone() ?? new JObject() };

    public async ValueTask DisposeAsync()
    {
        lock (_gate)
        {
            if (_disposed) return;
            _disposed = true;
        }
        Stop();
        _lifetime.Cancel();
        await _watchdog.ConfigureAwait(false);
        _lifetime.Dispose();
        // A native skill owns the capture gate until it exits. Do not dispose
        // synchronization primitives underneath a late native completion.
    }
}
