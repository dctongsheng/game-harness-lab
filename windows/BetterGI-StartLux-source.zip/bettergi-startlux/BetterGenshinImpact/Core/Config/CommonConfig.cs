using BetterGenshinImpact.Helpers;
using CommunityToolkit.Mvvm.ComponentModel;
using System;
using System.Collections.Generic;
using System.Windows.Media;
using Wpf.Ui.Controls;

namespace BetterGenshinImpact.Core.Config;

/// <summary>
/// 主题类型配置
/// </summary>
public enum ThemeType
{
    DarkNone,
    DarkMica,
    DarkAcrylic,
    LightNone,
    LightMica,
    LightAcrylic,
}


/// <summary>
///     遮罩窗口配置
/// </summary>
[Serializable]
public partial class CommonConfig : ObservableObject
{
    /// <summary>
    ///     是否启用遮罩窗口
    /// </summary>
    [ObservableProperty]
    private bool _screenshotEnabled;

    /// <summary>
    ///     UID遮盖是否启用
    /// </summary>
    [ObservableProperty]
    private bool _screenshotUidCoverEnabled = true;

    /// <summary>
    ///     是否保存奖励识别调试截图
    /// </summary>
    [ObservableProperty]
    private bool _rewardRecognitionScreenshotEnabled;

    /// <summary>
    ///     退出时最小化至托盘
    /// </summary>
    [ObservableProperty]
    private bool _exitToTray;

    /// <summary>
    /// 当前主题类型（新版主题）
    /// </summary>
    [ObservableProperty]
    private ThemeType _currentThemeType = OsVersionHelper.IsWindows11_22523_OrGreater ? ThemeType.DarkMica : ThemeType.DarkNone;

    /// <summary>
    /// 主题（旧版主题，兼容性保留）
    /// </summary>
    [ObservableProperty]
    private WindowBackdropType _currentBackdropType = WindowBackdropType.Mica;

    /// <summary>
    /// 是否启用主窗口自定义背景图
    /// </summary>
    [ObservableProperty]
    private bool _mainBackgroundEnabled;

    /// <summary>
    /// 主窗口自定义背景图路径，空字符串表示未设置
    /// </summary>
    [ObservableProperty]
    private string _mainBackgroundImagePath = string.Empty;

    /// <summary>
    /// 主窗口背景图不透明度，数值越小背景越淡，文字越清晰
    /// </summary>
    [ObservableProperty]
    private double _mainBackgroundOpacity = 0.35;

    /// <summary>
    /// 主窗口背景图拉伸模式
    /// </summary>
    [ObservableProperty]
    private Stretch _mainBackgroundStretch = Stretch.UniformToFill;

    /// <summary>
    /// 是否是第一次运行
    /// </summary>
    [ObservableProperty]
    private bool _isFirstRun = true;

    /// <summary>
    /// 这个版本是否运行过
    /// </summary>
    [ObservableProperty]
    private string _runForVersion = string.Empty;

    /// <summary>
    /// 一个设备只运行一次的已运行设备ID列表
    /// </summary>
    [ObservableProperty]
    private List<string> _onceHadRunDeviceIdList = new();
    
    
    /// <summary>
    /// 当前看过的兑换码推送版本
    /// </summary>
    [ObservableProperty]
    private string _redeemCodeFeedsUpdateVersion = "20251013";

    /// <summary>
    /// 国服兑换码更新是否允许通知
    /// </summary>
    [ObservableProperty]
    private bool _redeemCodeCnFeedsNotificationEnabled = true;

    /// <summary>
    /// 国际服兑换码更新是否允许通知
    /// </summary>
    [ObservableProperty]
    private bool _redeemCodeGlobalFeedsNotificationEnabled;

    /// <summary>
    /// 当前看过的国际服兑换码推送版本
    /// </summary>
    [ObservableProperty]
    private string _redeemCodeGlobalFeedsUpdateVersion = string.Empty;
}
