using BetterGenshinImpact.Core.Input;
using BetterGenshinImpact.Core.Config;
using BetterGenshinImpact.Core.Recognition;
using BetterGenshinImpact.Core.Recognition.OCR;
using BetterGenshinImpact.Core.Recognition.OpenCv;
using BetterGenshinImpact.Core.Simulator.Extensions;
using BetterGenshinImpact.GameTask.AutoSkip.Audio;
using BetterGenshinImpact.GameTask.AutoSkip.Assets;
using BetterGenshinImpact.GameTask.AutoSkip.Model;
using BetterGenshinImpact.GameTask.Common;
using BetterGenshinImpact.GameTask.Common.Element.Assets;
using BetterGenshinImpact.GameTask.Model.Area;
using BetterGenshinImpact.Helpers;
using BetterGenshinImpact.Service;
using BetterGenshinImpact.View.Windows;
using Microsoft.Extensions.Logging;
using OpenCvSharp;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text.Json;
using System.Text.RegularExpressions;
using System.Threading;
using BetterGenshinImpact.GameTask.AutoPick.Assets;
using BetterGenshinImpact.GameTask.Common.BgiVision;
using Vanara.PInvoke;
using Region = BetterGenshinImpact.GameTask.Model.Area.Region;

namespace BetterGenshinImpact.GameTask.AutoSkip;

/// <summary>
/// 自动剧情有选项点击
/// </summary>
public partial class AutoSkipTrigger : ITaskTrigger
{
    private readonly ILogger<AutoSkipTrigger> _logger = App.GetLogger<AutoSkipTrigger>();

    public string Name => "自动剧情";

    /// <summary>
    /// 用户开关，始终读全局配置。脚本启用时不看这个值（与原来"强制启用"一致）
    /// </summary>
    public bool IsEnabledByConfig => TaskContext.Instance().Config.AutoSkipConfig.Enabled;

    public int Priority => 20;
    public bool IsExclusive => false;
    
    public GameUiCategory SupportedGameUiCategory => GameUiCategory.Talk;

    /// <summary>
    /// 实时读取当前生效的配置（全局配置或脚本传入的配置）
    /// </summary>
    public bool IsBackgroundRunning => _config.RunBackgroundEnabled;
    
    public bool UseBackgroundOperation { get; private set; }

    public bool IsUseInteractionKey { get; set; } = false;
    
    private const int PlayingFlagDisappearDelaySeconds = 10; // 播放标识消失后继续识别的秒数
    private const int PageCloseRecognitionDelayMilliseconds = 200;

    /// <summary>
    /// 构造时指定的配置：无参构造为全局配置，内部调用方可以传入自定义配置
    /// </summary>
    private readonly AutoSkipConfig _defaultConfig;

    private readonly bool _isDefaultCustomConfiguration;

    /// <summary>
    /// 本次启用期间生效的配置。脚本通过 AddTrigger 传入 AutoSkipConfig 时使用它，否则使用 _defaultConfig
    /// </summary>
    private AutoSkipConfig _config;

    private readonly DialogueOptionAudioWaiter _dialogueOptionAudioWaiter = new();

    internal DialogueOptionAudioWaiter VoiceWaiter => _dialogueOptionAudioWaiter;

    /// <summary>
    /// 不自动点击的选项，优先级低于橙色文字点击
    /// </summary>
    private List<string> _defaultPauseList = [];

    /// <summary>
    /// 不自动点击的选项
    /// </summary>
    private List<string> _pauseList = [];

    /// <summary>
    /// 优先自动点击的选项
    /// </summary>
    private List<string> _selectList = [];
    
    private static RecognitionObject GetRecognitionObject(string objectName, ImageRegion region)
    {
        return RecognitionAssets.Get("AutoSkip", objectName, region.Width, region.Height);
    }

    public AutoSkipTrigger()
    {
        _defaultConfig = TaskContext.Instance().Config.AutoSkipConfig;
        _config = _defaultConfig;
    }
    
    /// <summary>
    /// 用于内部的其他方法调用，调用方需自行调用 OnEnabled(null) 后再调用 OnCapture
    /// </summary>
    /// <param name="config"></param>
    public AutoSkipTrigger(AutoSkipConfig config)
    {
        _defaultConfig = config;
        _isDefaultCustomConfiguration = true;
        _config = config;
    }

    /// <summary>
    /// 选定本次生效的配置，并重置运行状态。使用全局配置时读取关键词文件，使用自定义配置时不使用关键词
    /// </summary>
    /// <param name="options">脚本传入的 AutoSkipConfig，没有则为 null</param>
    public void OnEnabled(object? options)
    {
        var customConfig = options as AutoSkipConfig;
        _config = customConfig ?? _defaultConfig;
        // IsUseInteractionKey = _config.SelectChatOptionType == SelectChatOptionTypes.UseInteractionKey;

        _prevPlayingTime = DateTime.MinValue;
        _prevExecute = DateTime.MinValue;
        _prevHangoutExecute = DateTime.MinValue;
        _prevGetDailyRewardsTime = DateTime.MinValue;
        _prevClickTime = DateTime.MinValue;
        _prevBringToFrontTime = DateTime.MinValue;
        _chooseOptionDelayUntil = DateTime.MinValue;
        _chooseOptionWaitRecheckUntil = DateTime.MinValue;
        _pendingBringToFront = false;
        ResetPageCloseRecognition();

        _defaultPauseList = [];
        _pauseList = [];
        _selectList = [];
        if (customConfig == null && !_isDefaultCustomConfiguration)
        {
            InitKeyword();
        }
    }

    public void OnDisabled()
    {
        ReleaseChooseOptionWait("触发器关闭");
        ResetPageCloseRecognition();
    }

    private void InitKeyword()
    {
        try
        {
            var defaultPauseListJson = Global.ReadAllTextIfExist(@"Assets\Config\Skip\default_pause_options.json");
            if (!string.IsNullOrEmpty(defaultPauseListJson))
            {
                _defaultPauseList = JsonSerializer.Deserialize<List<string>>(defaultPauseListJson, ConfigService.JsonOptions) ?? [];
            }
        }
        catch (Exception e)
        {
            _logger.LogError(e, "读取自动剧情默认暂停点击关键词列表失败");
            // 在截图线程上读取，弹窗投递到 UI 线程，不等待用户确认
            UIDispatcherHelper.BeginInvoke(() => ThemedMessageBox.Error("读取自动剧情默认暂停点击关键词列表失败，请确认修改后的自动剧情默认暂停点击关键词内容格式是否正确！"));
        }

        try
        {
            var pauseListJson = Global.ReadAllTextIfExist(@"Assets\Config\Skip\pause_options.json");
            if (!string.IsNullOrEmpty(pauseListJson))
            {
                _pauseList = JsonSerializer.Deserialize<List<string>>(pauseListJson, ConfigService.JsonOptions) ?? [];
            }
        }
        catch (Exception e)
        {
            _logger.LogError(e, "读取自动剧情暂停点击关键词列表失败");
            UIDispatcherHelper.BeginInvoke(() => ThemedMessageBox.Error("读取自动剧情暂停点击关键词列表失败，请确认修改后的自动剧情暂停点击关键词内容格式是否正确！"));
        }

        try
        {
            var selectListJson = Global.ReadAllTextIfExist(@"Assets\Config\Skip\select_options.json");
            if (!string.IsNullOrEmpty(selectListJson))
            {
                _selectList = JsonSerializer.Deserialize<List<string>>(selectListJson, ConfigService.JsonOptions) ?? [];
            }
        }
        catch (Exception e)
        {
            _logger.LogError(e, "读取自动剧情优先点击选项列表失败");
            UIDispatcherHelper.BeginInvoke(() => ThemedMessageBox.Error("读取自动剧情优先点击选项列表失败，请确认修改后的自动剧情优先点击选项内容格式是否正确！"));
        }
    }

    /// <summary>
    /// 上一次播放中的帧
    /// </summary>
    private DateTime _prevPlayingTime = DateTime.MinValue;

    private DateTime _prevExecute = DateTime.MinValue;
    private DateTime _prevHangoutExecute = DateTime.MinValue;

    private DateTime _prevGetDailyRewardsTime = DateTime.MinValue;

    private DateTime _prevClickTime = DateTime.MinValue;
    private DateTime _prevBringToFrontTime = DateTime.MinValue;
    private DateTime _chooseOptionDelayUntil = DateTime.MinValue;
    private DateTime _chooseOptionWaitRecheckUntil = DateTime.MinValue;
    private DateTime _pageCloseRecognitionStartTime = DateTime.MinValue;
    private bool _pendingBringToFront;

    public void OnCapture(CaptureContent content)
    {
        RefreshOperationMode();
        if (!_config.AutoWaitDialogueOptionVoiceEnabled)
        {
            if (_dialogueOptionAudioWaiter.IsWaiting)
            {
                CancelChooseOptionWait("人声检测配置关闭");
            }

            _dialogueOptionAudioWaiter.ReleaseDetector();
        }

        // 找左上角剧情自动的按钮

        var isPlaying = content.CurrentGameUiCategory == GameUiCategory.Talk
                        || Bv.IsInTalkUi(content.CaptureRectArea); // 播放中

        if (IsChooseOptionWaiting())
        {
            if (!HasDialogueAdvanceTarget(content.CaptureRectArea, isPlaying))
            {
                CancelChooseOptionWait("对话或选项已变化");
            }
            else
            {
                UpdateChooseOptionWait();
                ResetPageCloseRecognition();
                return;
            }
        }

        if ((DateTime.Now - _prevExecute).TotalMilliseconds <= 200)
        {
            return;
        }

        _prevExecute = DateTime.Now;

        GetDailyRewardsEsc(_config, content);

        if (isPlaying && UseBackgroundOperation)
        {
            _pendingBringToFront = true;
        }
        else if (!isPlaying)
        {
            TryBringToFrontAfterBackgroundDialog();
        }

        if (!isPlaying && (DateTime.Now - _prevPlayingTime).TotalSeconds <= PlayingFlagDisappearDelaySeconds)
        {
            // 关闭弹出页
            if (_config.ClosePopupPagedEnabled)
            {
                ClosePopupPage(content);
                CloseItemPopup(content);
                CloseCharacterPopup(content);
            }
            else
            {
                ResetPageCloseRecognition();
            }

            // 自动剧情点击3s内判断
            if ((DateTime.Now - _prevPlayingTime).TotalMilliseconds < 3000)
            {
                if (!_config.SubmitGoodsEnabled)
                {
                    return;
                }

                // 提交物品
                if (SubmitGoods(content))
                {
                    return;
                }
            }
        }
        else
        {
            ResetPageCloseRecognition();
        }

        if (isPlaying)
        {
            _prevPlayingTime = DateTime.Now;
            if (_config.QuicklySkipConversationsEnabled)
            {
                if (_config.BeforeClickConfirmDelay > 0)
                {
                    // 在触发点击动作之前延迟时间
                    Thread.Sleep(_config.BeforeClickConfirmDelay);
                }
                if (IsUseInteractionKey)
                {
                    InputHub.Background.SimulateAction(GIActions.PickUpOrInteract); // 注意这里不是交互键 NOTE By Ayu0K: 这里确实是交互键
                }
                else
                {
                    InputHub.Background.Keyboard.KeyPress(User32.VK.VK_SPACE);
                }
            }

            // 对话选项选择
            bool hasOption;
            if (UseBackgroundOperation || IsUseInteractionKey)
            {
                hasOption = ChatOptionChooseUseKey(content.CaptureRectArea);
            }
            else
            {
                hasOption = ChatOptionChoose(content.CaptureRectArea);
            }


            // 邀约选项选择 1s 1次
            if (_config.AutoHangoutEventEnabled && !hasOption)
            {
                if ((DateTime.Now - _prevHangoutExecute).TotalMilliseconds < 1200)
                {
                    return;
                }

                _prevHangoutExecute = DateTime.Now;
                HangoutOptionChoose(content.CaptureRectArea);
            }
        }
        else
        {
            ClickBlackGameScreen(content);
        }
    }

    private void TryBringToFrontAfterBackgroundDialog()
    {
        if (!_config.BringGameToFrontAfterBackgroundDialogEnabled || !_pendingBringToFront)
        {
            return;
        }

        if (SystemControl.IsGenshinImpactActive())
        {
            _pendingBringToFront = false;
            return;
        }

        if ((DateTime.Now - _prevPlayingTime).TotalSeconds <= PlayingFlagDisappearDelaySeconds
            || (DateTime.Now - _prevBringToFrontTime).TotalSeconds <= 3)
        {
            return;
        }

        _prevBringToFrontTime = DateTime.Now;
        SystemControl.ActivateWindow();
        _pendingBringToFront = false;
        _logger.LogInformation("自动剧情：后台对话结束，已自动切回游戏前台");
    }

    /// <summary>
    /// 黑屏点击判断
    /// </summary>
    /// <param name="content"></param>
    /// <returns></returns>
    private bool ClickBlackGameScreen(CaptureContent content)
    {
        // 黑屏剧情要点击鼠标（多次） 几乎全黑的时候不用点击
        if ((DateTime.Now - _prevClickTime).TotalMilliseconds > 1200)
        {
            using var grayMat = new Mat(content.CaptureRectArea.CacheGreyMat, new Rect(0, content.CaptureRectArea.CacheGreyMat.Height / 3, content.CaptureRectArea.CacheGreyMat.Width, content.CaptureRectArea.CacheGreyMat.Height / 3));
            var blackCount = OpenCvCommonHelper.CountGrayMatColor(grayMat, 0);
            var rate = blackCount * 1d / (grayMat.Width * grayMat.Height);
            if (rate is >= 0.5 and < 0.98999)
            {
                if (UseBackgroundOperation)
                {
                    InputHub.Background.Mouse.LeftButtonClick();
                }
                else
                {
                    InputHub.Foreground.Mouse.LeftButtonClick();
                }

                _logger.LogInformation("自动剧情：{Text} 比例 {Rate}", "点击黑屏", rate.ToString("F"));

                _prevClickTime = DateTime.Now;
                return true;
            }
        }

        return false;
    }

    private void HangoutOptionChoose(ImageRegion captureRegion)
    {
        var selectedRects = captureRegion.FindMulti(GetRecognitionObject("HangoutSelected", captureRegion));
        var unselectedRects = captureRegion.FindMulti(GetRecognitionObject("HangoutUnselected", captureRegion));
        if (selectedRects.Count > 0 || unselectedRects.Count > 0)
        {
            List<HangoutOption> hangoutOptionList =
            [
                .. selectedRects.Select(selectedRect => new HangoutOption(selectedRect, true)),
                .. unselectedRects.Select(unselectedRect => new HangoutOption(unselectedRect, false)),
            ];
            var allHangoutOptions = hangoutOptionList;
            try
            {
                // 文字区域不存在的识别结果不能参与选择。
                hangoutOptionList = hangoutOptionList.Where(hangoutOption => hangoutOption.TextRect != null).ToList();
                if (hangoutOptionList.Count == 0)
                {
                    return;
                }

                // OCR识别选项文字
                foreach (var hangoutOption in hangoutOptionList)
                {
                    var text = OcrFactory.Paddle.Ocr(hangoutOption.TextRect!.SrcMat);
                    hangoutOption.OptionTextSrc = StringUtils.RemoveAllEnter(text);
                }

                // 历史已选状态不影响当前路线，目标分支仍需优先匹配全部选项。
                if (!string.IsNullOrEmpty(_config.AutoHangoutEndChoose)
                    && HangoutConfig.Instance.HangoutOptions.TryGetValue(_config.AutoHangoutEndChoose, out var chooseList))
                {
                    var target = FindHangoutTargetOption(hangoutOptionList, chooseList);
                    if (target != null)
                    {
                        HangoutOptionClick(target);
                        _logger.LogInformation("邀约分支[{Text}]关键词命中，选择[{Option}]", _config.AutoHangoutEndChoose, target.OptionTextSrc);
                        AutoHangoutSkipLog(target.OptionTextSrc);
                        captureRegion.DrawingBoard.Clear("HangoutSelected");
                        captureRegion.DrawingBoard.Clear("HangoutUnselected");
                        return;
                    }
                }

                // 没有命中目标分支时，优先选择未点击的选项。
                var unselectedOption = hangoutOptionList.FirstOrDefault(hangoutOption => !hangoutOption.IsSelected);
                if (unselectedOption != null)
                {
                    HangoutOptionClick(unselectedOption);
                    AutoHangoutSkipLog(unselectedOption.OptionTextSrc);
                    captureRegion.DrawingBoard.Clear("HangoutSelected");
                    captureRegion.DrawingBoard.Clear("HangoutUnselected");
                    return;
                }

                // 没有未点击的选项时选择第一个已点击选项，推进对话状态。
                HangoutOptionClick(hangoutOptionList[0]);
                AutoHangoutSkipLog(hangoutOptionList[0].OptionTextSrc);
                captureRegion.DrawingBoard.Clear("HangoutSelected");
                captureRegion.DrawingBoard.Clear("HangoutUnselected");
            }
            finally
            {
                foreach (var hangoutOption in allHangoutOptions)
                {
                    hangoutOption.Dispose();
                }
            }
        }
        else
        {
            // 没有邀约选项 寻找跳过按钮
            if (_config.AutoHangoutPressSkipEnabled)
            {
                using var skipRa = captureRegion.Find(GetRecognitionObject("HangoutSkip", captureRegion));
                if (skipRa.IsExist())
                {
                    if (UseBackgroundOperation && !SystemControl.IsGenshinImpactActive())
                    {
                        skipRa.BackgroundClick();
                    }
                    else
                    {
                        skipRa.Click();
                    }

                    AutoHangoutSkipLog("点击跳过按钮");
                }
            }
        }
    }

    private static HangoutOption? FindHangoutTargetOption(
        IEnumerable<HangoutOption> options,
        IEnumerable<string> keywords)
    {
        var normalizedOptions = options
            .Select(option => new
            {
                Option = option,
                Text = NormalizeHangoutText(option.OptionTextSrc)
            })
            .Where(item => !string.IsNullOrEmpty(item.Text))
            .ToList();

        return keywords
            .Select(keyword => new
            {
                Keyword = keyword,
                Text = NormalizeHangoutText(keyword)
            })
            .Where(item => !string.IsNullOrEmpty(item.Text))
            .SelectMany(keyword => normalizedOptions
                .Where(option => option.Text.Contains(keyword.Text, StringComparison.Ordinal))
                .Select(option => new
                {
                    option.Option,
                    option.Text,
                    Keyword = keyword.Text,
                    IsExact = string.Equals(option.Text, keyword.Text, StringComparison.Ordinal)
                }))
            .OrderByDescending(item => item.IsExact)
            .ThenByDescending(item => item.Keyword.Length)
            .ThenBy(item => item.Option.IconRect.Top)
            .Select(item => item.Option)
            .FirstOrDefault();
    }

    private static string NormalizeHangoutText(string text)
    {
        return new string(text
            .Where(character => !char.IsWhiteSpace(character) && !char.IsPunctuation(character))
            .ToArray());
    }

    private bool IsOrangeOption(Mat textMat)
    {
        // 只提取橙色
        // Cv2.ImWrite($"log/text{DateTime.Now:yyyyMMddHHmmssffff}.png", textMat);
        using var bMat = OpenCvCommonHelper.Threshold(textMat, new Scalar(243, 195, 48), new Scalar(255, 205, 55));
        var whiteCount = OpenCvCommonHelper.CountGrayMatColor(bMat, 255);
        var rate = whiteCount * 1.0 / (bMat.Width * bMat.Height);
        Debug.WriteLine($"识别到橙色文字区域占比:{rate}");
        if (rate > 0.06)
        {
            return true;
        }

        return false;
    }

    /// <summary>
    /// 领取每日委托奖励 后 10s 寻找原石是否出现，出现则点击(960, 900)坐标处
    /// </summary>
    private void GetDailyRewardsEsc(AutoSkipConfig config, CaptureContent content)
    {
        if (!config.AutoGetDailyRewardsEnabled)
        {
            return;
        }

        if ((DateTime.Now - _prevGetDailyRewardsTime).TotalSeconds > 10)
        {
            return;
        }

        content.CaptureRectArea.Find(GetRecognitionObject("Primogem", content.CaptureRectArea), primogemRa =>
        {
            Thread.Sleep(100);
            GameCaptureRegion.GameRegion1080PPosMove(960, 900);
            InputHub.Background.Mouse.LeftButtonClick();
            _prevGetDailyRewardsTime = DateTime.MinValue;
            primogemRa.Dispose();
        });
    }

    [GeneratedRegex(@"^[a-zA-Z0-9]+$")]
    private static partial Regex EnOrNumRegex();

    /// <summary>
    /// 5.2 版本直接交互键就能使用的对话选择
    /// </summary>
    /// <param name="region"></param>
    /// <returns></returns>
    private bool ChatOptionChooseUseKey(ImageRegion region)
    {
        if (_config.IsClickNoneChatOption())
        {
            return false;
        }
        
        using var chatOptionResult = region.Find(GetRecognitionObject("OptionIcon", region));
        var isInChat = false;
        isInChat = chatOptionResult.IsExist();
        if (!isInChat)
        {
            using var pickRa = region.Find(AutoPickAssets.Get(region, TaskContext.Instance().Config.AutoPickConfig.PickKey).ChatPickRo);
            isInChat = pickRa.IsExist();
        }

        if (isInChat)
        {
            if (!PrepareBeforeChooseOption())
            {
                return true;
            }

            var fKey = AutoPickAssets.Get(region, TaskContext.Instance().Config.AutoPickConfig.PickKey).PickVk;
            if (_config.IsClickFirstChatOption())
            {
                InputHub.Background.Keyboard.KeyPress(fKey);
            }
            else if (_config.IsClickRandomChatOption())
            {
                var random = new Random();
                // 随机 0~4 的数字
                var r = random.Next(0, 5);
                for (var j = 0; j < r; j++)
                {
                    InputHub.Background.Keyboard.KeyPress(User32.VK.VK_S);
                    Thread.Sleep(100);
                }

                Thread.Sleep(50);
                InputHub.Background.Keyboard.KeyPress(fKey);
            }
            else
            {
                InputHub.Background.Keyboard.KeyPress(User32.VK.VK_W);
                Thread.Sleep(100);
                InputHub.Background.Keyboard.KeyPress(fKey);
            }
            
            AutoSkipLog("交互键点击(后台)");

            return true;
        }

        return false;
    }

    /// <summary>
    /// 新的对话选项选择
    ///
    /// 返回 true 表示存在对话选项，但是不一定点击了
    /// </summary>
    private bool ChatOptionChoose(ImageRegion region)
    {
        var assetScale = TaskContext.Instance().SystemInfo.AssetScale;
        if (!_config.IsClickNoneChatOption())
        {
            // 感叹号识别 遇到直接点击
            using var exclamationIconRa = region.Find(GetRecognitionObject("ExclamationIcon", region));
            if (!exclamationIconRa.IsEmpty())
            {
                if (!PrepareBeforeChooseOption())
                {
                    return true;
                }

                exclamationIconRa.Click();
                AutoSkipLog("点击感叹号选项");
                return true;
            }
        }

        // 气泡识别
        var chatOptionResultList = region.FindMulti(GetRecognitionObject("OptionIcon", region));
        if (chatOptionResultList.Count > 0)
        {
            // 第一个元素就是最下面的
            chatOptionResultList = [.. chatOptionResultList.OrderByDescending(r => r.Y)];

            // 通过最下面的气泡框来文字识别
            var lowest = chatOptionResultList[0];
            var ocrRect = new Rect((int)(lowest.X + lowest.Width + 8 * assetScale), region.Height / 12,
                (int)(535 * assetScale), (int)(lowest.Y + lowest.Height + 30 * assetScale - region.Height / 12d));
            var ocrResList = region.FindMulti(new RecognitionObject
            {
                RecognitionType = RecognitionTypes.Ocr,
                RegionOfInterest = ocrRect
            });
            //using var ocrMat = new Mat(region.SrcGreyMat, ocrRect);
            //// Cv2.ImWrite("log/ocrMat.png", ocrMat);
            //var ocrRes = OcrFactory.Paddle.OcrResult(ocrMat);

            // 删除为空的结果 和 纯英文的结果
            var rs = new List<Region>();
            // 按照y坐标排序
            ocrResList = [.. ocrResList.OrderBy(r => r.Y)];
            for (var i = 0; i < ocrResList.Count; i++)
            {
                var item = ocrResList[i];
                if (string.IsNullOrEmpty(item.Text) || (item.Text.Length < 5 && EnOrNumRegex().IsMatch(item.Text)))
                {
                    continue;
                }

                if (i != ocrResList.Count - 1)
                {
                    if (ocrResList[i + 1].Y - ocrResList[i].Y > 150)
                    {
                        Debug.WriteLine($"存在Y轴偏差过大的结果，忽略:{item.Text}");
                        continue;
                    }
                }

                rs.Add(item);
            }

            if (rs.Count > 0)
            {
                // 自定义优先选项匹配
                if (_config.CustomPriorityOptionsEnabled && !string.IsNullOrEmpty(_config.CustomPriorityOptions))  
                {  
                    var customOptions = _config.CustomPriorityOptions  
                        .Split(new[] { '\r', '\n', ';', '；' }, StringSplitOptions.RemoveEmptyEntries)  
                        .Select(s => s.Trim())  
                        .Where(s => !string.IsNullOrEmpty(s))  
                        .ToList();  
      
                    foreach (var item in rs)  
                    {
                        foreach (var customOption in customOptions)  
                        {
                            if (item.Text.Contains(customOption))  
                            {
                                if (!ClickOcrRegion(item))
                                {
                                    return true;
                                }

                                return true;  
                            }  
                        }  
                    }  
                }
                
                if(_config.IsClickNoneChatOption()){
                    return false;
                }
                
                
                if (!_config.SkipBuiltInClickOptions)
                {
                    // 内置关键词 匹配
                    foreach (var item in rs)
                    {
                        // 选择关键词
                        if (_selectList.Any(s => item.Text.Contains(s)))
                        {
                            if (!ClickOcrRegion(item))
                            {
                                return true;
                            }

                            return true;
                        }

                        // 不选择关键词
                        if (_pauseList.Any(s => item.Text.Contains(s)))
                        {
                            return true;
                        }
                    }

                    // 橙色选项
                    foreach (var item in rs)
                    {
                        var textMat = item.ToImageRegion().SrcMat;
                        if (IsOrangeOption(textMat))
                        {
                            if (_config.AutoGetDailyRewardsEnabled && (item.Text.Contains("每日") || item.Text.Contains("委托")))
                            {
                                if (!ClickOcrRegion(item, "每日委托"))
                                {
                                    return true;
                                }

                                TaskControl.Sleep(800);
                                
                                // 6.2 每日提示确认
                                var ra1 = TaskControl.CaptureToRectArea();
                                if (Bv.ClickBlackConfirmButton(ra1))
                                {
                                    _logger.LogInformation("存在提示并确认");
                                }
                                ra1.Dispose();
                                
                                _prevGetDailyRewardsTime = DateTime.Now; // 记录领取时间
                            }
                            else if (_config.AutoReExploreEnabled && (item.Text.Contains("探索") || item.Text.Contains("派遣")))
                            {
                                if (!ClickOcrRegion(item, "探索派遣"))
                                {
                                    return true;
                                }

                                Thread.Sleep(800); // 等待探索派遣界面打开
                                new OneKeyExpeditionTask().Run();
                            }
                            else if (!item.Text.Contains("每日")
                                && !item.Text.Contains("委托")
                                && !item.Text.Contains("探索")
                                && !item.Text.Contains("派遣"))
                            {
                                if (!ClickOcrRegion(item))
                                {
                                    return true;
                                }
                            }

                            return true;
                        }
                    }

                    // 默认不选择关键词
                    foreach (var item in rs)
                    {
                        // 不选择关键词
                        if (_defaultPauseList.Any(s => item.Text.Contains(s)))
                        {
                            return true;
                        }
                    }
                }

                // 最后，选择默认选项
                var clickRegion = rs[^1];
                if (_config.IsClickFirstChatOption())
                {
                    clickRegion = rs[0];
                }
                else if (_config.IsClickRandomChatOption())
                {
                    var random = new Random();
                    clickRegion = rs[random.Next(0, rs.Count)];
                }

                if (!ClickOcrRegion(clickRegion))
                {
                    return true;
                }
            }
            else
            {
                var clickRect = lowest;
                if (_config.IsClickFirstChatOption())
                {
                    clickRect = chatOptionResultList[^1];
                }

                // 没OCR到文字，直接选择气泡选项
                if (!ClickOcrRegion(clickRect))
                {
                    return true;
                }

                var msg = _config.IsClickFirstChatOption() ? "第一个" : "最后一个";
                AutoSkipLog($"点击{msg}气泡选项");
            }

            return true;
        }
        else
        {
            // 没有气泡的时候识别 F 选项
            var pickAssets = AutoPickAssets.Get(region, TaskContext.Instance().Config.AutoPickConfig.PickKey);
            using var pickRa = region.Find(pickAssets.ChatPickRo);
            if (pickRa.IsExist())
            {
                InputHub.Background.Keyboard.KeyPress(pickAssets.PickVk);
                AutoSkipLog("无气泡图标，但存在交互键，直接按下交互键");
            }
        }

        return false;
    }

    private bool ClickOcrRegion(Region region, string optionType = "")
    {
        if (string.IsNullOrEmpty(optionType))
        {
            if (!PrepareBeforeChooseOption())
            {
                return false;
            }
        }

        RefreshOperationMode();
        if (UseBackgroundOperation && !SystemControl.IsGenshinImpactActive())
        {
            region.BackgroundClick();
        }
        else
        {
            region.Click();
        }

        AutoSkipLog(region.Text);
        return true;
    }

    private bool PrepareBeforeChooseOption()
    {
        RefreshOperationMode();
        if (DateTime.Now <= _chooseOptionWaitRecheckUntil)
        {
            return true;
        }

        if (IsChooseOptionWaiting())
        {
            return false;
        }

        if (_config.AutoWaitDialogueOptionVoiceEnabled)
        {
            var waitingStarted = _dialogueOptionAudioWaiter.Start(
                Math.Clamp(_config.DialogueOptionVoiceMaxWaitSeconds, 0, 600) * 1000,
                _config.AfterChooseOptionSleepDelay,
                _logger);

            return !waitingStarted;
        }

        if (_config.AfterChooseOptionSleepDelay > 0)
        {
            _chooseOptionDelayUntil = DateTime.Now.AddMilliseconds(_config.AfterChooseOptionSleepDelay);
            return false;
        }

        return true;
    }

    private bool UpdateChooseOptionWait()
    {
        var waitCompleted = false;
        if (_dialogueOptionAudioWaiter.IsWaiting && _dialogueOptionAudioWaiter.Update(_logger))
        {
            waitCompleted = true;
        }

        if (_chooseOptionDelayUntil != DateTime.MinValue && DateTime.Now >= _chooseOptionDelayUntil)
        {
            _chooseOptionDelayUntil = DateTime.MinValue;
            waitCompleted = true;
        }

        if (!waitCompleted)
        {
            return false;
        }

        RefreshOperationMode();
        _chooseOptionWaitRecheckUntil = DateTime.Now.AddMilliseconds(1200);
        _logger.LogDebug("自动剧情：选项等待结束，放弃本轮旧识别结果，等待下一帧重新判断选项与前后台状态");
        return true;
    }

    private bool IsChooseOptionWaiting()
    {
        return _dialogueOptionAudioWaiter.IsWaiting || _chooseOptionDelayUntil != DateTime.MinValue;
    }

    private void CancelChooseOptionWait(string reason)
    {
        if (!IsChooseOptionWaiting())
        {
            return;
        }

        _dialogueOptionAudioWaiter.Cancel();
        _chooseOptionDelayUntil = DateTime.MinValue;
        _chooseOptionWaitRecheckUntil = DateTime.MinValue;
        _logger.LogDebug("自动剧情：选项等待取消，原因：{Reason}", reason);
    }

    private void ReleaseChooseOptionWait(string reason)
    {
        var hadWait = IsChooseOptionWaiting();
        _dialogueOptionAudioWaiter.Cancel();
        _dialogueOptionAudioWaiter.ReleaseDetector();
        _chooseOptionDelayUntil = DateTime.MinValue;
        _chooseOptionWaitRecheckUntil = DateTime.MinValue;
        if (hadWait)
        {
            _logger.LogDebug("自动剧情：选项等待取消，原因：{Reason}", reason);
        }
    }

    private bool HasDialogueOption(ImageRegion region)
    {
        using var chatOptionResult = region.Find(GetRecognitionObject("OptionIcon", region));
        if (chatOptionResult.IsExist())
        {
            return true;
        }

        using var pickRa = region.Find(AutoPickAssets.Get(region, TaskContext.Instance().Config.AutoPickConfig.PickKey).ChatPickRo);
        if (pickRa.IsExist())
        {
            return true;
        }

        using var exclamationIconRa = region.Find(GetRecognitionObject("ExclamationIcon", region));
        return !exclamationIconRa.IsEmpty();
    }

    private bool HasDialogueAdvanceTarget(ImageRegion region, bool isPlaying)
    {
        if (isPlaying && HasDialogueOption(region))
        {
            return true;
        }

        if (Bv.IsInMainUi(region) || Bv.IsInBigMapUi(region))
        {
            return false;
        }

        return TryHandleBottomTriangle(region, (_, _, _) => { });
    }

    private void RefreshOperationMode()
    {
        UseBackgroundOperation = IsBackgroundRunning && !SystemControl.IsGenshinImpactActive();
    }

    private void HangoutOptionClick(HangoutOption option)
    {
        if (_config.AutoHangoutChooseOptionSleepDelay > 0)
        {
            Thread.Sleep(_config.AutoHangoutChooseOptionSleepDelay);
        }

        if (UseBackgroundOperation && !SystemControl.IsGenshinImpactActive())
        {
            option.BackgroundClick();
        }
        else
        {
            option.Click();
        }
    }

    private void AutoHangoutSkipLog(string text)
    {
        if ((DateTime.Now - _prevClickTime).TotalMilliseconds > 1000)
        {
            _logger.LogInformation("自动邀约：{Text}", text);
        }

        _prevClickTime = DateTime.Now;
    }

    private void AutoSkipLog(string text)
    {
        if (text.Contains("每日委托") || text.Contains("探索派遣"))
        {
            _logger.LogInformation("自动剧情：{Text}", text);
        }
        else if ((DateTime.Now - _prevClickTime).TotalMilliseconds > 1000)
        {
            _logger.LogInformation("自动剧情：{Text}", text);
        }

        _prevClickTime = DateTime.Now;
    }

    /// <summary>
    /// 关闭弹出页
    /// </summary>
    /// <param name="content"></param>
    private void ClosePopupPage(CaptureContent content)
    {
        if (!_config.ClosePopupPagedEnabled)
        {
            ResetPageCloseRecognition();
            return;
        }
        
        content.CaptureRectArea.Find(GetRecognitionObject("PageClose", content.CaptureRectArea), pageCloseRoRa =>
        {
            using (pageCloseRoRa)
            {
                var now = DateTime.Now;
                if (_pageCloseRecognitionStartTime == DateTime.MinValue)
                {
                    _pageCloseRecognitionStartTime = now;
                    return;
                }

                if ((now - _pageCloseRecognitionStartTime).TotalMilliseconds < PageCloseRecognitionDelayMilliseconds)
                {
                    return;
                }

                using var guidingNotesRa = content.CaptureRectArea.Find(GetRecognitionObject("GuidingNotes", content.CaptureRectArea));
                using var chatHistoryRa = content.CaptureRectArea.Find(GetRecognitionObject("ChatHistory", content.CaptureRectArea));
                using var valiantChroniclesRa = content.CaptureRectArea.Find(GetRecognitionObject("ValiantChronicles", content.CaptureRectArea));
                if (!guidingNotesRa.IsEmpty() || !chatHistoryRa.IsEmpty()|| !valiantChroniclesRa.IsEmpty())
                {
                    return;
                }

                if (!Bv.IsInBigMapUi(content.CaptureRectArea))
                {
                    InputHub.Background.Keyboard.KeyPress(User32.VK.VK_ESCAPE);

                    AutoSkipLog("关闭弹出页");
                    ResetPageCloseRecognition();
                }
            }
        }, ResetPageCloseRecognition);
    }

    private void ResetPageCloseRecognition()
    {
        _pageCloseRecognitionStartTime = DateTime.MinValue;
    }
    
    private DateTime _prevCloseItemTime = DateTime.MinValue;
    /// <summary>
    /// 关闭剧情中弹出的道具页面
    /// </summary>
    /// <param name="content"></param>
    private void CloseItemPopup(CaptureContent content)
    {
        if ((DateTime.Now - _prevCloseItemTime).TotalMilliseconds < 1000)
        {
            return; 
        }
        
        if (Bv.IsInMainUi(content.CaptureRectArea) || Bv.IsInBigMapUi(content.CaptureRectArea))  
        {  
            return;  
        }  

        TryHandleBottomTriangle(content.CaptureRectArea, (croppedRegion, triangleRect, area) =>
        {
            if (!PrepareBeforeChooseOption())
            {
                return;
            }

            using var triangleRegion = croppedRegion.Derive(triangleRect);
            if (UseBackgroundOperation && !SystemControl.IsGenshinImpactActive())
            {
                triangleRegion.BackgroundClick();
            }
            else
            {
                triangleRegion.Click();
            }

            _prevCloseItemTime = DateTime.Now;
            _logger.LogInformation("自动剧情：{Text} 面积 {Area}", "点击底部三角形", area);
            _prevPlayingTime = DateTime.Now; // 此时认为还在自动剧情
        });
    }

    private bool TryHandleBottomTriangle(ImageRegion captureRegion, Action<ImageRegion, Rect, double> onFound)
    {
        // 屏幕底部中间，实心三角的位置
        var scale = TaskContext.Instance().SystemInfo.AssetScale;
        //不同场景的三角高度不同,几乎不能再小了
        using var croppedRegion = captureRegion.DeriveCrop(945 * scale, 980 * scale, 30 * scale, 80 * scale);

        using var hsv = new Mat();
        Cv2.CvtColor(croppedRegion.SrcMat, hsv, ColorConversionCodes.BGR2HSV);

        using var yellowMask = new Mat();
        using var buleMask = new Mat();
        Cv2.InRange(hsv, new Scalar(0, 240, 229), new Scalar(25, 255, 255), yellowMask);
        Cv2.InRange(hsv, new Scalar(90, 156, 145), new Scalar(99, 208, 253), buleMask);

        Cv2.FindContours(yellowMask, out var yellowContours, out _, RetrievalModes.External, ContourApproximationModes.ApproxSimple);
        Cv2.FindContours(buleMask, out var buleMaskContours, out _, RetrievalModes.External, ContourApproximationModes.ApproxSimple);

        var mergedContours = yellowContours.Concat(buleMaskContours).ToArray();
        foreach (var contour in mergedContours)
        {
            var area = Cv2.ContourArea(contour);
            var approx = Cv2.ApproxPolyDP(contour, 0.04 * Cv2.ArcLength(contour, true), true);
            
            if (area < 10 || area > 50 || approx.Length != 3) continue; 

            onFound(croppedRegion, Cv2.BoundingRect(approx), area);
            return true;
        }

        return false;
    }

    /// <summary>
    /// 关闭剧情中弹出的初见角色信息弹窗
    /// </summary>
    /// <param name="content"></param>
    private void CloseCharacterPopup(CaptureContent content)
    {
        using var srcMat = content.CaptureRectArea.SrcMat.Clone();
        var scale = TaskContext.Instance().SystemInfo.AssetScale;
        // 把被角色头像遮挡的矩形闭合（假设矩形存在）
        Cv2.Rectangle(srcMat, new Rect((int)(240 * scale), (int)(395 * scale), (int)(300 * scale), (int)(50 * scale)), new Scalar(229, 241, 245), -1);
        Cv2.Rectangle(srcMat, new Rect((int)(290 * scale), (int)(660 * scale), (int)(210 * scale), (int)(40 * scale)), new Scalar(101, 82, 74), -1);
        
        using var hsv = new Mat();
        Cv2.CvtColor(srcMat, hsv, ColorConversionCodes.BGR2HSV);

        // 颜色阈值分割 - 背景色中的黄跟藏青
        using var maskLight = new Mat();
        using var maskDark = new Mat();
        Cv2.InRange(hsv, new Scalar(18, 16, 234), new Scalar(27, 19, 250), maskLight);
        Cv2.InRange(hsv, new Scalar(101, 57, 95), new Scalar(118, 85, 106), maskDark);

        // 合并掩码并进行形态学操作 - 减少背景中的噪点
        using var combinedMask = new Mat();
        using var kernel = Cv2.GetStructuringElement(MorphShapes.Rect, new Size(21, 21));
        Cv2.BitwiseOr(maskLight, maskDark, combinedMask);
        Cv2.MorphologyEx(combinedMask, combinedMask, MorphTypes.Close, kernel);
        Cv2.MorphologyEx(combinedMask, combinedMask, MorphTypes.Open, kernel);

        // 查找轮廓  
        Cv2.FindContours(combinedMask, out var contours, out _, RetrievalModes.External, ContourApproximationModes.ApproxSimple);

        var imgHeight = srcMat.Height;
        var imgWidth = srcMat.Width;

        // 筛选弹窗轮廓 
        foreach (var contour in contours)
        {
            var bbox = Cv2.BoundingRect(contour);
            if (bbox.Height == 0) continue;

            // 面积检查
            var areaRatio = (double)(bbox.Width * bbox.Height) / (imgWidth * imgHeight);
            if (areaRatio <= 0.24 || areaRatio >= 0.3) continue; // 弹窗高约300，面积比约等于0.27
            _logger.LogDebug("自动剧情：关闭角色弹窗-面积检查通过");

            // 宽高比检查
            var aspectRatio = (double)bbox.Width / bbox.Height;
            if (aspectRatio < 5.6 || aspectRatio > 7.2) continue;
            _logger.LogDebug("自动剧情：关闭角色弹窗-宽高比检查通过");

            // 位置检查
            if (bbox.Y <= imgHeight * 0.3 || bbox.Y + bbox.Height >= imgHeight * 0.7) continue;
            _logger.LogDebug("自动剧情：关闭角色弹窗-位置检查通过");


            // 检查是否包含两种颜色  
            var lightCount = Cv2.CountNonZero(new Mat(maskLight, bbox));
            var darkCount = Cv2.CountNonZero(new Mat(maskDark, bbox));
            if (lightCount <= 0 || darkCount <= 0) continue;

            if (UseBackgroundOperation && !SystemControl.IsGenshinImpactActive())
            {
                content.CaptureRectArea.Derive(bbox).BackgroundClick();
            }
            else
            {
                content.CaptureRectArea.ClickTo(100, 100); // 点击角色横幅外的区域才能跳过
            }

            _logger.LogInformation("自动剧情：关闭角色弹窗");
            _prevPlayingTime  = DateTime.Now; // 此时认为还在自动剧情
            return;
        }
    }

    private bool SubmitGoods(CaptureContent content)
    {
        using var exclamationRa = content.CaptureRectArea.Find(GetRecognitionObject("SubmitExclamationIcon", content.CaptureRectArea));
        if (!exclamationRa.IsEmpty())
        {
            // var rects = MatchTemplateHelper.MatchOnePicForOnePic(content.CaptureRectArea.SrcMat.CvtColor(ColorConversionCodes.BGRA2BGR),
            //     _autoSkipAssets.SubmitGoodsMat, TemplateMatchModes.SqDiffNormed, null, 0.9, 4);
            var param = new MorphologyParam(new Size(5,5), MorphTypes.Close, 2);
            var rects = ContoursHelper.FindSpecifyColorRects(content.CaptureRectArea.SrcMat, new Scalar(233, 229, 220), 100, 20, param);
            if (rects.Count == 0)
            {
                return false;
            }

            // 画矩形并保存
            // foreach (var rect in rects)
            // {
            //     Cv2.Rectangle(content.CaptureRectArea.SrcMat, rect, Scalar.Red, 1);
            // }
            // Cv2.ImWrite("log/提交物品.png", content.CaptureRectArea.SrcMat);

            for (var i = 0; i < rects.Count; i++)
            {
                content.CaptureRectArea.Derive(rects[i]).Click();
                _logger.LogInformation("提交物品：{Text}", "1. 选择物品" + i);
                TaskControl.Sleep(800);

                using var ra1 = TaskControl.CaptureToRectArea(forceNew: true);
                var btnBlackConfirmRa = ra1.Find(ElementRecognition.Get("BtnBlackConfirm", ra1));
                if (!btnBlackConfirmRa.IsEmpty())
                {
                    btnBlackConfirmRa.Click();
                    _logger.LogInformation("提交物品：{Text}", "2. 放入" + i);
                    TaskControl.Sleep(200);
                }
            }

            TaskControl.Sleep(500);

            using var ra2 = TaskControl.CaptureToRectArea(forceNew: true);
            using var btnWhiteConfirmRa = ra2.Find(ElementRecognition.Get("BtnWhiteConfirm", ra2));
            if (!btnWhiteConfirmRa.IsEmpty())
            {
                btnWhiteConfirmRa.Click();
                _logger.LogInformation("提交物品：{Text}", "3. 交付");

                ra2.DrawingBoard.ClearAll();
            }

            // 最多4个物品 现在就支持一个
            // var prevGoodsRect = Rect.Empty;
            // for (var i = 1; i <= 4; i++)
            // {
            //     // 不断的截取出右边的物品
            //     TaskControl.Sleep(200);
            //     content = TaskControl.CaptureToContent();
            //     var gameArea = content.CaptureRectArea;
            //     if (prevGoodsRect != Rect.Empty)
            //     {
            //         var r = content.CaptureRectArea.ToRect();
            //         var newX = prevGoodsRect.X + prevGoodsRect.Width;
            //         gameArea = content.CaptureRectArea.Crop(new Rect(newX, 0, r.Width - newX, r.Height));
            //         Cv2.ImWrite($"log/物品{i}.png", gameArea.SrcMat);
            //     }
            //
            //     var goods = gameArea.Find(_autoSkipAssets.SubmitGoodsRo);
            //     if (!goods.IsEmpty())
            //     {
            //         prevGoodsRect = goods.ConvertRelativePositionToCaptureArea();
            //         goods.ClickCenter();
            //         _logger.LogInformation("提交物品：{Text}", "1. 选择物品" + i);
            //
            //         TaskControl.Sleep(800);
            //         content = TaskControl.CaptureToContent();
            //
            //         var btnBlackConfirmRa = content.CaptureRectArea.Find(ElementAssets.Instance().BtnBlackConfirm);
            //         if (!btnBlackConfirmRa.IsEmpty())
            //         {
            //             btnBlackConfirmRa.ClickCenter();
            //             _logger.LogInformation("提交物品：{Text}", "2. 放入" + i);
            //
            //             TaskControl.Sleep(800);
            //             content = TaskControl.CaptureToContent();
            //
            //             btnBlackConfirmRa = content.CaptureRectArea.Find(ElementAssets.Instance().BtnBlackConfirm);
            //             if (!btnBlackConfirmRa.IsEmpty())
            //             {
            //                 _logger.LogInformation("提交物品：{Text}", "2. 仍旧存在物品");
            //                 continue;
            //             }
            //             else
            //             {
            //                 var btnWhiteConfirmRa = content.CaptureRectArea.Find(ElementAssets.Instance().BtnWhiteConfirm);
            //                 if (!btnWhiteConfirmRa.IsEmpty())
            //                 {
            //                     btnWhiteConfirmRa.ClickCenter();
            //                     _logger.LogInformation("提交物品：{Text}", "3. 交付");
            //
            //                     VisionContext.Instance().DrawContent.ClearAll();
            //                     return true;
            //                 }
            //                 break;
            //             }
            //         }
            //     }
            //     else
            //     {
            //         break;
            //     }
            // }
        }

        return false;
    }
}
