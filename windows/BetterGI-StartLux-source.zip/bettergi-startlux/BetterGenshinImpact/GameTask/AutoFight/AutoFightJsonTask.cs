using BetterGenshinImpact.Core.Input;
using BetterGenshinImpact.Core.Simulator.Extensions;
using BetterGenshinImpact.GameTask.AutoFight.Assets;
using BetterGenshinImpact.GameTask.AutoFight.Model;
using BetterGenshinImpact.GameTask.AutoFight.Script;
using BetterGenshinImpact.GameTask.AutoGeniusInvokation.Exception;
using BetterGenshinImpact.GameTask.Model.Area;
using BetterGenshinImpact.Helpers;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using static BetterGenshinImpact.GameTask.Common.TaskControl;
using BetterGenshinImpact.GameTask.Common.Job;
using OpenCvSharp;
using BetterGenshinImpact.GameTask.AutoPick.Assets;
using BetterGenshinImpact.Core.Recognition;
using BetterGenshinImpact.GameTask.Common.Element.Assets;
using BetterGenshinImpact.GameTask.Common;
using BetterGenshinImpact.GameTask.AutoPathing.Handler;
using BetterGenshinImpact.GameTask.AutoPathing.Model;

namespace BetterGenshinImpact.GameTask.AutoFight;

public class AutoFightJsonTask : ISoloTask
{
    public string Name => "自动战斗(JSON策略)";

    private readonly AutoFightParam _taskParam;
    private readonly JsonCombatStrategy _strategy;
    private CancellationToken _ct;

    private DateTime _lastFightFlagTime = DateTime.Now;
    private int _skipCheckCounter;

    private readonly ReturnMainUiTask _returnMainUiTask = new();
    private readonly double _assetScale = TaskContext.Instance().SystemInfo.AssetScale;
    private readonly double _dpi = TaskContext.Instance().DpiScale;

    private static readonly object PickLock = new object();

    /// <summary>
    /// 当前队伍中的角色名集合（用于过滤动作节点）
    /// </summary>
    private HashSet<string> _teamCharacterNames = new(StringComparer.OrdinalIgnoreCase);

    // 日志防刷：1秒内同一动作名至多输出一次日志
    private string _lastLoggedActionName = "";
    private DateTime _lastLogTime = DateTime.MinValue;

    /// <summary>
    /// 当前操作的角色名（私有状态，不污染全局 CurrentAvatarName）
    /// </summary>
    private string _currentAvatarName = "";

    /// <summary>
    /// 展开后的优先级动作条目
    /// 每个 JsonAction 展开为 1+N 个条目（1个主条件 + N个 morePriorities）
    /// </summary>
    private class PrioritizedAction
    {
        public JsonAction Action { get; set; }
        public string Expression { get; set; }
        public int Priority { get; set; }
    }

    // 战斗点位
    public static WaypointForTrack? FightWaypoint { get; set; } = null;

    private AutoFightTask.TaskFightFinishDetectConfig _finishDetectConfig;

    public AutoFightJsonTask(AutoFightParam taskParam)
    {
        _taskParam = taskParam;
        _strategy = JsonCombatStrategyParser.ParseFile(_taskParam.CombatStrategyPath);

        _finishDetectConfig = new AutoFightTask.TaskFightFinishDetectConfig(_taskParam);
    }

    /// <summary>
    /// 启动自动战斗（JSON策略模式）
    /// </summary>
    /// <param name="ct">取消令牌</param>
    public async Task Start(CancellationToken ct)
    {
        _ct = ct;
        AvatarRecognition.SetCurrentAutoFightParam(_taskParam);
        AvatarRecognition.ClearLegendaryBarTracker();
        CancellationTokenSource? cts2 = null;
        CancellationTokenRegistration cts2Registration = default;
        ExperienceDetector? expDetector = null;

        async Task StopExperienceDetectorAsync()
        {
            var detector = expDetector;
            if (detector == null) return;

            expDetector = null;
            try
            {
                await detector.StopAsync();
            }
            finally
            {
                detector.Dispose();
            }
        }

        try
        {
            LogScreenResolution();
            var combatScenes = CombatScenes.GetCombatScenesWithRetry();
    
            // 收集当前队伍角色名
            foreach (var avatar in combatScenes.GetAvatars())
            {
                _teamCharacterNames.Add(avatar.Name);
            }
            Logger.LogInformation("JSON 策略：当前队伍角色：{Names}", string.Join(", ", _teamCharacterNames));
    
            // 过滤可用动作：Character 为空（通用）或在当前队伍中
            var filteredActions = _strategy.Actions
                .Where(a => string.IsNullOrEmpty(a.Character) || _teamCharacterNames.Contains(a.Character))
                .ToList();
    
            // 展开为优先级条目：每个动作产生 1个主条目 + N个 morePriorities 条目
            var validActions = new List<PrioritizedAction>();
            foreach (var action in filteredActions)
            {
                validActions.Add(new PrioritizedAction
                {
                    Action = action,
                    Expression = action.Condition.Expression,
                    Priority = action.Index
                });
    
                foreach (var morePriority in action.MorePriorities)
                {
                    validActions.Add(new PrioritizedAction
                    {
                        Action = action,
                        Expression = morePriority.Expression,
                        Priority = morePriority.Priority
                    });
                }
            }
    
            // 按优先级排序（LINQ OrderBy 为稳定排序）：同优先级条目保持策略中的出现顺序，
            // 即动作声明顺序（每个动作的主条件条目在前、morePriorities 紧随其后，添加顺序即出现顺序）
            validActions = validActions
                .OrderBy(p => p.Priority)
                .ToList();
    
            Logger.LogInformation("JSON 策略：共 {Total} 个动作，展开为 {Expanded} 个优先级条目",
                _strategy.Actions.Count, validActions.Count);
    
            if (validActions.Count == 0)
            {
                Logger.LogWarning("JSON 策略：没有可用的动作节点，跳过战斗");
                return;
            }
    
            // 新的取消token
            cts2 = new CancellationTokenSource();
            cts2Registration = ct.Register(cts2.Cancel);
    
            combatScenes.BeforeTask(cts2.Token);
            // 设置初始当前角色名（用于无 Character 字段的通用 action 回退）
            _currentAvatarName = combatScenes.GetAvatars().FirstOrDefault()?.Name ?? _currentAvatarName;
            TimeSpan fightTimeout = TimeSpan.FromSeconds(_taskParam.Timeout);
            Stopwatch timeoutStopwatch = Stopwatch.StartNew();
    
            AutoFightSeek.RotationCount = 0;
            AutoFightTask.FightStatusFlag = true;
    
            var fightEndFlag = false;
            var timeOutFlag = false;
            string lastFightName = "";
    
            // 初始化条件求值器（传入策略动作名，供条件词法按名称合并连字符）
            var evaluator = new ConditionEvaluator(combatScenes, () => CaptureToRectArea(),
                _strategy.Actions.Where(a => !string.IsNullOrEmpty(a.Name)).Select(a => a.Name));
    
            // 基于经验值的战后拾取检测
            if (_taskParam.KazuhaPickupEnabled && _taskParam.ExpBasedPickupEnabled)
            {
                using var gameCaptureRegion = CaptureToRectArea();
                var expRos = AutoFightAssets.Get(gameCaptureRegion).ExperienceRecognitionObjects;
                expDetector = new ExperienceDetector(expRos, cts2.Token);
                expDetector.Start();
            }

            // 战斗前动作
            await RunPreActions(combatScenes, evaluator);
    
            // 战斗操作
            var fightTask = Task.Run(async () =>
            {
                try
                {
                    JsonAction? lastExecutedAction = null;
                    // 战斗开始时重置最近一次检查时间，供更快触发战斗结束检查判断间隔使用
                    AutoFightTask.LastFightFinishCheckTime = DateTime.Now;
                    // 记录开战时间，供"开战后一段时间阻断战斗结束检查"使用
                    AutoFightTask.FightStartTime = DateTime.Now;
                    // 每场新战斗重置"敌人可见时跳过战斗结束检查"的连续跳过计数
                    AutoFightTask.ResetSkipCheckCounter();
                    TimeSpan checkFightFinishTime = TimeSpan.FromSeconds(_finishDetectConfig.CheckTime); //检查战斗结束的超时时间

                    // 更快触发战斗结束检查（参照 txt 逻辑）：满足时间/人名条件时触发一次检查，无论是否发生换人；
                    // 未发生换人时没有切人动作提供后摇等待，因此仍需要应用前摇等待
                    // 返回是否检测到战斗结束
                    async Task<bool> FastCheckFightFinishAsync(string prevName, string actionName, bool afterSwitch = false)
                    {
                        if (_taskParam is not { FightFinishDetectEnabled: true } || !_finishDetectConfig.FastCheckEnabled)
                            return false;

                        // 本动作执行后的实际角色（无 Character 时沿用当前角色）
                        var checkAvatarName = string.IsNullOrEmpty(actionName) ? _currentAvatarName : actionName;

                        if ((_finishDetectConfig.CheckTime > 0 &&
                             (DateTime.Now - AutoFightTask.LastFightFinishCheckTime) > checkFightFinishTime)
                            || _finishDetectConfig.CheckNames.Contains(prevName))
                        {
                            // LastFightFinishCheckTime 由 CheckFightFinish 内部更新（动作中的 check 指令也会更新）
                            // 切人后检查：切人动作已包含上一个动作后摇的等待，前置延时缩短为 50ms，仅保留检测界面打开后的 DetectDelayTime；
                            // 若本动作未发生换人，则没有切人动作提供后摇等待，仍需应用前摇等待
                            int delayTime = _finishDetectConfig.DelayTime;
                            if (afterSwitch && checkAvatarName != prevName)
                            {
                                delayTime = 50;
                            }
                            else if (_finishDetectConfig.DelayTimes.TryGetValue(prevName, out var characterDelayTime))
                            {
                                delayTime = characterDelayTime;
                            }

                            var endFlag = await AutoFightTask.CheckFightFinish(_finishDetectConfig, _ct,
                                delayTime, _finishDetectConfig.DetectDelayTime);
                            if (endFlag)
                            {
                                Logger.LogInformation("{Name} 检测到战斗结束", actionName);
                                return true;
                            }
                        }
                        return false;
                    }

                    while (!cts2.Token.IsCancellationRequested)
                    {
                        if (timeoutStopwatch.Elapsed > fightTimeout)
                        {
                            Logger.LogInformation("战斗超时结束");
                            fightEndFlag = true;
                            timeOutFlag = true;
                            break;
                        }
    
                        // 每次循环开始：截图一次，供所有条件求值复用
                        using var capture = CaptureToRectArea();
                        evaluator.SetCachedCapture(capture);

                        var anyExecuted = false;

                        // 记录本轮循环开始时的角色，用于检测是否发生换人
                        var prevAvatarName = _currentAvatarName;

                        foreach (var prioritizedAction in validActions)
                            {
                                if (cts2.Token.IsCancellationRequested) break;
    
                                var action = prioritizedAction.Action;
    
                                // 求值条件表达式：当前动作序号（用于 since/last-exec/count 缺省指代本动作）传动作真实 Index，
                                // 不能传排序用的 Priority（MorePriority 条目的 Priority 与该动作 Index 不同，会导致缺省查询查不到记录）
                                var conditionMet = evaluator.Evaluate(
                                    prioritizedAction.Expression,
                                    action.Index,
                                    action.Character,
                                    action.Name);
    
                                if (!conditionMet)
                                {
                                    continue;
                                }

                                // 更快触发战斗结束检查（默认在切人前触发；开启"切人后再执行战斗结束检查"时改为切人后触发）
                                var fightEndDetected = false;

                                // 切人前检查（默认时机）
                                if (!_finishDetectConfig.CheckAfterSwitchAvatar)
                                {
                                    fightEndDetected = await FastCheckFightFinishAsync(prevAvatarName, action.Character);
                                }

                                // 指定角色的动作：执行前确保切换到该角色（战斗已结束时跳过切人）
                                if (!fightEndDetected && !string.IsNullOrEmpty(action.Character))
                                {
                                    var avatar = combatScenes.SelectAvatar(action.Character);
                                    if (avatar == null) continue;

                                    avatar.Switch();
                                    _currentAvatarName = action.Character;
                                }

                                // 切人后再执行战斗结束检查：复用切人等待上一个动作后摇的时间，检查无需再等待
                                if (_finishDetectConfig.CheckAfterSwitchAvatar)
                                {
                                    fightEndDetected = await FastCheckFightFinishAsync(prevAvatarName, action.Character, afterSwitch: true);
                                }

                                if (fightEndDetected)
                                {
                                    _fightEndFlag = true;
                                    // 战斗结束则跳过当前动作（切人、执行均不进行）
                                    break;
                                }
    
                                // 执行动作
                                await ExecuteAction(combatScenes, action);
    
                                // 确保E技能释放成功
                                if (action.EnsureCast)
                                {
                                    var characterName = string.IsNullOrEmpty(action.Character)
                                        ? _currentAvatarName
                                        : action.Character;
                                    var avatar = combatScenes.SelectAvatar(characterName);
                                    if (avatar != null)
                                    {
                                        var imageAfterAction = CaptureToRectArea();
                                        try
                                        {
                                            var retry = 5;
                                            while (!(await AutoFightSkill.AvatarSkillAsync(Logger, avatar, false, 1, _ct, imageAfterAction)) && retry > 0)
                                            {
                                                Logger.LogWarning("{Name} 未检测到技能冷却，重新执行", action.Name);
                                                // 防止在纳塔飞天或爬墙
                                                InputHub.ReleaseAll();
                                                InputHub.Foreground.SimulateAction(GIActions.NormalAttack);
                                                InputHub.Foreground.SimulateAction(GIActions.Drop);
                                                await Delay(200, _ct);
                                                // 重新执行整个动作
                                                await ExecuteAction(combatScenes, action);
                                                var previousImage = imageAfterAction;
                                                imageAfterAction = CaptureToRectArea();
                                                previousImage.Dispose();
                                                await Task.Delay(30, _ct);
                                                retry--;
                                            }
                                        }
                                        finally
                                        {
                                            imageAfterAction.Dispose();
                                        }
                                    }
                                }
    
                                evaluator.UpdateLastExecTime(action.Index, action.Name);
                                lastExecutedAction = action;
                                anyExecuted = true;
                                lastFightName = action.Character ?? "";
    
                                if (_fightEndFlag) break;

                                // 执行完第一个满足条件的动作后重新判断
                                break;
                            }
    
                        if (fightEndFlag || _fightEndFlag) break;
    
                        if (!anyExecuted)
                        {
                            await Delay(200, _ct);
                        }
                    }
                }
                catch (Exception e)
                {
                    Debug.WriteLine(e.Message);
                    Debug.WriteLine(e.StackTrace);
                    throw;
                }
                finally
                {
                    InputHub.ReleaseAll();
                    AutoFightTask.FightStatusFlag = false;
                }
            }, cts2.Token);
    
            // 在持续索敌循环启动前标记战斗进行中，避免索敌循环因 FightStatusFlag 仍为 false 而立即退出
            AutoFightTask.FightStatusFlag = true;
    
            // 启动持续索敌循环（异步后台运行，与战斗任务并发）
            // 使用独立的 CancellationTokenSource，以便在战后独立取消索敌循环，不影响 cts2 关联的其他组件（如 expDetector）
            using var targetingCts = CancellationTokenSource.CreateLinkedTokenSource(cts2.Token);
            Task? targetingTask = null;
            if (_taskParam.EnableCombatTargeting)
            {
                targetingTask = Task.Run(async () =>
                {
                    try
                    {
                        await AvatarRecognition.ContinuousTargetingLoopAsync(targetingCts.Token, () => !AutoFightTask.FightStatusFlag);
                    }
                    catch (OperationCanceledException) { }
                    catch (Exception e)
                    {
                        Logger.LogError(e, "持续索敌循环异常");
                    }
                }, targetingCts.Token);
            }
    
            try
            {
                await fightTask;
            }
            finally
            {
                // 战斗结束后（无论正常/异常），停止并等待索敌循环完成清理（ReleaseAllKey / MiddleButtonClick），
                // 避免其 finally 在拾取/切人过程中释放按键，干扰万叶E吸怪等操作
                if (targetingTask != null)
                {
                    await targetingCts.CancelAsync();
                    try { await targetingTask; } catch (OperationCanceledException) { }
                }
                AutoFightTask.FightStatusFlag = false;
            }
    
            try
            {
                // 基于经验值检测结果的拾取判断
                if (_taskParam.KazuhaPickupEnabled && _taskParam.ExpBasedPickupEnabled && expDetector != null)
                {
                    if (!expDetector.HasDetectedExperience)
                    {
                        Logger.LogInformation("基于经验值判断：等待经验值检测结果");
                        var waitMs = 1100;
                        while (!expDetector.HasDetectedExperience && waitMs > 0)
                        {
                            await Delay(100, _ct);
                            waitMs -= 100;
                        }
                    }
    
                    var shouldPickup = expDetector.HasDetectedExperience;
                    Logger.LogInformation("基于经验值判断：{Result} 战后拾取", shouldPickup ? "执行" : "不执行");
    
                    if (!shouldPickup)
                    {
                        if (_taskParam is { PickDropsAfterFightEnabled: true })
                        {
                            await new ScanPickTask().Start(_ct, _taskParam.PickDropsAfterFightSeconds);
                        }
                        return;
                    }
                }
            }
            finally
            {
                await StopExperienceDetectorAsync();
            }
    
            // 战后拾取（完全参照 AutoFightTask）
            await PostFightPickup(combatScenes, timeOutFlag, lastFightName);
        }
        finally
        {
            // 战斗可能在创建 fightTask 前因复活/恢复异常退出，统一清理战斗状态。
            AutoFightTask.FightStatusFlag = false;
            AvatarRecognition.ClearCurrentAutoFightParam();
            try
            {
                await StopExperienceDetectorAsync();
            }
            catch (Exception e)
            {
                Logger.LogWarning(e, "停止 JSON 战斗经验检测时发生异常");
            }
            try
            {
                cts2?.Cancel();
            }
            catch (Exception e)
            {
                Logger.LogWarning(e, "取消 JSON 战斗令牌时发生异常");
            }
            finally
            {
                cts2Registration.Dispose();
                cts2?.Dispose();
            }
        }
    }

    private bool _fightEndFlag;

    /// <summary>执行单个 JSON 动作节点</summary>
    private async Task ExecuteAction(CombatScenes combatScenes, JsonAction action)
    {
        try
        {
            var character = string.IsNullOrEmpty(action.Character)
                ? _currentAvatarName
                : action.Character;

            var commands = CombatScriptParser.ParseLinePart(action.Action, character);

            // 执行前输出日志
            LogActionOnce(action.Name);

            CombatCommand? lastSubCmd = null;
            foreach (var cmd in commands)
            {
                if (_ct.IsCancellationRequested) break;

                cmd.Execute(combatScenes, lastSubCmd);
                lastSubCmd = cmd;

                if (_fightEndFlag) break;

                // 仅由 check 指令触发战斗结束检测
                if (cmd.Method == Method.Check && _taskParam.FightFinishDetectEnabled)
                {
                    _fightEndFlag = await AutoFightTask.CheckFightFinish(_finishDetectConfig, _ct,
                        _finishDetectConfig.DelayTime, _finishDetectConfig.DetectDelayTime);
                    if (_fightEndFlag)
                    {
                        Logger.LogInformation("{Name} 检测到战斗结束", action.Name);
                        break;
                    }
                }
            }

            // 更新当前角色名，供后续无指定角色动作使用
            _currentAvatarName = character;
        }
        catch (RetryException)
        {
            // 复活/恢复信号必须传递给 PathExecutor，以便重跑当前路径段。
            throw;
        }
        catch (Exception e)
        {
            Logger.LogError("自动战斗：{Name} 执行失败：{Msg}", action.Name, e.Message);
        }
        finally
        {
            InputHub.ReleaseAll();
        }
    }

    /// <summary>日志防刷：同一动作名在1秒内至多输出一次日志</summary>
    private void LogActionOnce(string actionName)
    {
        if (actionName == _lastLoggedActionName && (DateTime.Now - _lastLogTime).TotalSeconds < 1)
        {
            return;
        }
        _lastLoggedActionName = actionName;
        _lastLogTime = DateTime.Now;
        Logger.LogInformation("自动战斗：{Name}", actionName);
    }

    /// <summary>执行战斗前动作</summary>
    private async Task RunPreActions(CombatScenes combatScenes, ConditionEvaluator evaluator)
    {
        if (_strategy.Info.PreActions == null || _strategy.Info.PreActions.Count == 0)
            return;

        Logger.LogInformation("JSON 策略：执行战斗前动作");
        using var capture = CaptureToRectArea();
        evaluator.SetCachedCapture(capture);

        foreach (var preAction in _strategy.Info.PreActions)
        {
            if (_ct.IsCancellationRequested) break;

            var firstSpaceIndex = preAction.IndexOf(' ');
            var character = _currentAvatarName;
            var commands = preAction;
            if (firstSpaceIndex > 0)
            {
                character = preAction[..firstSpaceIndex];
                commands = preAction[(firstSpaceIndex + 1)..];
            }

            var cmdList = CombatScriptParser.ParseLineCommands(commands, character);
            var combatScript = new CombatScript([character], cmdList);

            try
            {
                await CombatScriptExecutor.ExecuteAsync(combatScript, _ct, Logger, combatScenes);
            }
            catch (RetryException e)
            {
                Logger.LogWarning("战斗前动作要求中断当前战斗：{Msg}", e.Message);
                throw;
            }
            Logger.LogInformation("战斗前动作：{Action}", preAction);
            await Delay(300, _ct);
        }
    }

    /// <summary>战后拾取</summary>
    private async Task PostFightPickup(CombatScenes combatScenes, bool timeOutFlag, string lastFightName)
    {
        if (_taskParam.KazuhaPickupEnabled)
        {
            var picker = combatScenes.SelectAvatar("枫原万叶") ?? combatScenes.SelectAvatar("琴");

            string? oldPartyName = null;
            if (RunnerContext.Instance.PartyName is not null)
            {
                oldPartyName = RunnerContext.Instance.PartyName;
            }
            else if (picker is null && !string.IsNullOrEmpty(_taskParam.KazuhaPartyName))
            {
                Logger.LogWarning("换队拾取：当前队伍名称为空，尝试读取！");
                await Delay(1000, _ct);
                await _returnMainUiTask.Start(_ct);

                for (int attempt = 0; attempt < 6; attempt++)
                {
                    InputHub.Foreground.SimulateAction(GIActions.OpenPartySetupScreen);
                    var enterGameAppear = await NewRetry.WaitForElementAppear(
                        ElementRecognition.Get("PartyBtnChooseView"),
                        () => { },
                        _ct,
                        15,
                        500
                    );
                    if (attempt == 5 && !enterGameAppear)
                    {
                        Logger.LogWarning("换队拾取：读取队伍名称失败，跳过换队拾取步骤");
                        return;
                    }
                }
            }

            if (!string.IsNullOrEmpty(_taskParam.KazuhaPartyName))
            {
                await Delay(1000, _ct);

                var timeWaitStart = 0;
                while (timeWaitStart < 6000)
                {
                    using var ra = CaptureToRectArea();
                    var partyViewBtn = ra.Find(ElementRecognition.Get("PartyBtnChooseView"));
                    if (partyViewBtn.IsExist())
                    {
                        var rawPartyName = ra.Find(new RecognitionObject
                        {
                            RecognitionType = RecognitionTypes.Ocr,
                            RegionOfInterest = new Rect(partyViewBtn.Right, partyViewBtn.Top, (int)(350 * _assetScale),
                                partyViewBtn.Height)
                        }).Text;

                        if (string.IsNullOrWhiteSpace(rawPartyName))
                        {
                            oldPartyName = string.Empty;
                        }
                        else
                        {
                            var tempName = rawPartyName
                                .Replace("\"", "")
                                .Replace("\r\n", "")
                                .Replace("\r", "");

                            int firstNewLineIndex = tempName.IndexOf('\n');
                            if (firstNewLineIndex != -1)
                            {
                                tempName = tempName.Substring(0, firstNewLineIndex);
                            }

                            oldPartyName = tempName.Trim();
                        }

                        Logger.LogInformation("换队拾取：当前队伍名称读取为：{oldPartyName}", oldPartyName);
                        Logger.LogDebug("OCR原始识别文本（含转义）：{rawPartyName}", rawPartyName);
                        RunnerContext.Instance.PartyName = oldPartyName;
                        break;
                    }
                    await Delay(200, _ct);
                    timeWaitStart += 200;
                }
            }

            var switchPartyFlag = false;
            if (picker == null && !timeOutFlag && !string.IsNullOrEmpty(_taskParam.KazuhaPartyName) && oldPartyName != _taskParam.KazuhaPartyName)
            {
                try
                {
                    Logger.LogInformation($"切换为拾取队伍：{_taskParam.KazuhaPartyName}");
                    var success = await new SwitchPartyTask().Start(_taskParam.KazuhaPartyName, _ct);
                    if (success)
                    {
                        Logger.LogInformation($"成功切换队伍为{_taskParam.KazuhaPartyName}");
                        switchPartyFlag = true;
                        RunnerContext.Instance.PartyName = _taskParam.KazuhaPartyName;
                        RunnerContext.Instance.ClearCombatScenes();
                        var cs = await RunnerContext.Instance.GetCombatScenes(_ct);
                        picker = cs.SelectAvatar("枫原万叶") ?? cs.SelectAvatar("琴");
                    }
                }
                catch (Exception e)
                {
                    Logger.LogWarning("切换队伍异常，跳过此步骤！{Msg}", e.Message);
                }
            }

            if (picker != null)
            {
                InputHub.ReleaseAll();

                if (picker.Name == "枫原万叶")
                {
                    var time = TimeSpan.FromSeconds(picker.GetSkillCdSeconds());

                    bool shouldSkip = lastFightName == picker.Name && time.TotalSeconds > 3;
                    bool forcePickup = _taskParam.QinDoublePickUp;

                    if (forcePickup || !shouldSkip)
                    {
                        Logger.LogInformation("使用 枫原万叶-长E 拾取掉落物");
                        if (picker.TrySwitch(10))
                        {
                            await Delay(100, _ct);
                            await picker.WaitSkillCd(_ct);
                            await SimulateHoldElementalSkillAsync(800, _ct);
                            await SimulateMouseLeftClickLoopAsync(6, _ct);
                            await Delay(1500, _ct);
                            picker.AfterUseSkill();
                        }
                    }
                    else
                    {
                        Logger.LogInformation("距最近一次万叶出招，时间过短，跳过此次万叶拾取！");
                    }
                }
                else if (picker.Name == "琴")
                {
                    Logger.LogInformation("使用 琴-长E 拾取掉落物");

                    var actionsToUse = PickUpCollectHandler.PickUpActions
                        .Where(action => action.StartsWith("琴-长E" + " ", StringComparison.OrdinalIgnoreCase))
                        .Select(action => action.Replace("琴-长E", "琴", StringComparison.OrdinalIgnoreCase))
                        .ToArray();

                    var find = _taskParam.QinDoublePickUp;
                    if (picker.TrySwitch(10))
                    {
                        await Delay(100, _ct);
                        foreach (var miningActionStr in actionsToUse)
                        {
                            var pickUpAction = CombatScriptParser.ParseContext(miningActionStr);

                            for (int i = 0; i < 2; i++)
                            {
                                await picker.WaitSkillCd(_ct);
                                foreach (var command in pickUpAction.CombatCommands)
                                {
                                    command.Execute(combatScenes);
                                    Task.Run(() =>
                                    {
                                        if (Monitor.TryEnter(PickLock))
                                        {
                                            try
                                            {
                                                if (find)
                                                {
                                                    using (var imagePick = CaptureToRectArea())
                                                    {
                                                        if (imagePick.Find(AutoPickAssets.Get(imagePick, TaskContext.Instance().Config.AutoPickConfig.PickKey).PickRo).IsExist())
                                                        {
                                                            find = false;
                                                        }
                                                    }
                                                }
                                            }
                                            finally
                                            {
                                                Monitor.Exit(PickLock);
                                            }
                                        }
                                    });
                                }

                                if (!find)
                                {
                                    break;
                                }

                                if (i == 0)
                                {
                                    Logger.LogInformation("自动拾取；尝试再次执行 琴-长E 拾取");
                                    picker.AfterUseSkill();
                                }
                                else
                                {
                                    break;
                                }
                            }

                            InputHub.ReleaseAll();
                        }
                    }
                }
            }

            if (switchPartyFlag && !string.IsNullOrEmpty(oldPartyName))
            {
                try
                {
                    Logger.LogInformation($"切换为原队伍：{oldPartyName}");
                    var success = await new SwitchPartyTask().Start(oldPartyName, _ct);
                    if (success)
                    {
                        Logger.LogInformation($"切换为原队伍{oldPartyName}");
                        switchPartyFlag = true;
                        RunnerContext.Instance.PartyName = oldPartyName;
                        RunnerContext.Instance.ClearCombatScenes();
                        await RunnerContext.Instance.GetCombatScenes(_ct);
                    }
                }
                catch (Exception e)
                {
                    Logger.LogWarning("恢复原队伍失败，跳过此步骤！{Msg}", e.Message);
                }
            }
        }

        if (_taskParam is { PickDropsAfterFightEnabled: true })
        {
            await new ScanPickTask().Start(_ct, _taskParam.PickDropsAfterFightSeconds);
        }
    }

    /// <summary>
    /// 检查并记录屏幕分辨率
    /// </summary>
    private void LogScreenResolution()
    {
        AssertUtils.CheckGameResolution("自动战斗");
    }
}
