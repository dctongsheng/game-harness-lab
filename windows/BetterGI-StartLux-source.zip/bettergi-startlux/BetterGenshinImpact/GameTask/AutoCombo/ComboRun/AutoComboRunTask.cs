using BetterGenshinImpact.GameTask.AutoFight;
using BetterGenshinImpact.GameTask.AutoFight.Model;
using BetterGenshinImpact.GameTask.AutoCombo.ComboBuild;
using BetterGenshinImpact.GameTask.AutoGeniusInvokation.Exception;
using BetterGenshinImpact.GameTask.SkillCd;
using BetterGenshinImpact.Core.Mask;
using BetterGenshinImpact.ViewModel.Windows;
using System.Windows.Media;
using CsTrees;
using CsTrees.Display;
using CsTrees.Visitors;
using Microsoft.Extensions.Logging;
using System;
using System.ComponentModel;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using static BetterGenshinImpact.GameTask.AutoFight.AutoFightTask;
using static BetterGenshinImpact.GameTask.Common.TaskControl;

namespace BetterGenshinImpact.GameTask.AutoCombo.ComboRun;

/// <summary>
/// 已构建行为树的运行时持有者：建树任务完成后暂存建树会话，
/// 供测试按钮启动/暂停 Tick 循环（暂停只中断循环，下次启动重新 Build 复位行为状态）
/// </summary>
public static class AutoComboRuntime
{
    /// <summary>最近一次建树任务产出的建树会话，未建树时为 null</summary>
    public static ComboTreeSession? Session { get; set; }
}

/// <summary>
/// 连招行为树运行任务：循环 Tick 指定建树会话的行为树驱动战斗，取消即暂停
/// 每次启动都通过 Builder 重新 Build 出全新节点实例的树，天然完成行为状态复位
/// </summary>
public class AutoComboRunTask : ISoloTask
{
    public string Name => "自动连招运行";

    /// <summary>宿主场景的战斗意图：结束检测开关、拾取、超时等，任务按开关决定自身行为</summary>
    private readonly AutoFightParam _param;

    /// <summary>本次运行消费的建树会话：构造时强制注入，任务自身不读取任何静态状态</summary>
    private readonly ComboTreeSession _session;

    /// <summary>
    /// 本次运行所在运行环境的遮罩绘制入口，每次 Start 时取一次：任务可能在截图器启动前构造，暂停后也可能在新的运行环境里继续
    /// </summary>
    private IMaskWindowDrawingBoard _drawingBoard = NullMaskWindowDrawingBoard.Instance;

    public AutoComboRunTask(AutoFightParam param, ComboTreeSession session)
    {
        _param = param;
        _session = session;
    }

    public async Task Start(CancellationToken ct)
    {
        _drawingBoard = TaskContext.Instance().Runtime?.MaskWindowDrawingBoard ?? NullMaskWindowDrawingBoard.Instance;
        var session = _session;

        // 标准消费者协议：FromAvatars 重新识别队伍并校验与建树队伍一致，接管建树会话的 Avatar 实例 → BeforeTask 写入本任务令牌
        var combatScenes = CombatScenes.FromAvatars(_session.Avatars);
        combatScenes.BeforeTask(ct);

        // 清黑板（复位上次运行的键值状态）→ 重新 Build 得到全新节点实例的行为树（节点内状态随实例自然复位）
        var (comboTree, fallbackTree) = session.BindAndBuild();

        // 按宿主意图决定是否包装自带战斗结束检测：外部控制结束时（如秘境）关闭，只认取消令牌
        Behaviour extendedRoot;
        if (_param.FightFinishDetectEnabled)
        {
            Logger.LogInformation("{Name}扩展行为树：包装 LLM 树与战斗结束检测", Name);
            extendedRoot = new AutoComboRunBuilder(session.Avatars)
                .WithBlackboard(session.Blackboard)
                    .Sequence("-", true)
                        .CheckFightFinish("战斗结束检测")
                        .Selector("-", false)
                            .Leaf(() => comboTree)
                            .Leaf(() => fallbackTree)
                        .End()
                    .End()
                .End().Build();
        }
        else
        {
            Logger.LogInformation("{Name}使用宿主场景的结束控制，不包装战斗结束检测", Name);
            extendedRoot = new AutoComboRunBuilder(session.Avatars)
                .WithBlackboard(session.Blackboard)
                    .Selector("-", false)
                        .Leaf(() => comboTree)
                        .Leaf(() => fallbackTree)
                    .End()
                .End().Build();
        }

        Logger.LogInformation("{Name}任务启动，持续 Tick 行为树", Name);

        var tree = new BehaviourTree(extendedRoot);
        var snapshot = new SnapshotVisitor();
        tree.AddVisitor(snapshot);

        // 复用自动战斗配置的持续索敌开关：与 Tick 循环并发运行
        // 使用独立的 CancellationTokenSource，暂停/结束时先停索敌并等待其清理
        using var targetingCts = CancellationTokenSource.CreateLinkedTokenSource(ct);
        Task? targetingTask = null;
        if (TaskContext.Instance().Config.AutoFightConfig.EnableCombatTargeting)
        {
            targetingTask = Task.Run(async () =>
            {
                try
                {
                    await AvatarRecognition.ContinuousTargetingLoopAsync(targetingCts.Token, () => false);
                }
                catch (OperationCanceledException) { }
                catch (Exception e)
                {
                    Logger.LogError(e, "持续索敌循环异常");
                }
            }, targetingCts.Token);
        }

        // 全队战技 CD 遮罩显示：与 Tick 循环并发的后台展示循环，刷新间隔自定，与树 Tick 节奏解耦
        using var overlayCts = CancellationTokenSource.CreateLinkedTokenSource(ct);
        var overlayTask = Task.Run(async () =>
        {
            try
            {
                await TeamSkillCdOverlay.LoopAsync(_drawingBoard, overlayCts.Token, combatScenes);
            }
            catch (OperationCanceledException) { }
            catch (Exception e)
            {
                Logger.LogError(e, "全队战技CD遮罩循环异常");
            }
        }, overlayCts.Token);

        // 行为树与并发循环均已就绪，进入正式运行段：显示浮窗
        AutoComboTreeWindowService.Instance.Show();

        // E 技能识别结果显示：订阅 VM 通知，运行期间 Avatar 分类结果自动渲染到遮罩
        ESkillClassifyViewModel.Instance.PropertyChanged += OnESkillClassifyResultChanged;

        try
        {
            // 接管 CD 遮罩显示：挂起 SkillCd 触发器，避免两套 CD 显示叠加
            SkillCdTrigger.Suspend(_drawingBoard);

            while (!ct.IsCancellationRequested)
            {
                await tree.Tick();

                var vm = AutoComboTreeViewModel.Instance;

                // 只渲染本次 Tick 遍历的路径，未访问的子树折叠为占位符（主树与兜底树共用同一快照）
                var path = Display.AsciiTree(
                    comboTree,
                    showOnlyVisited: true,
                    visited: snapshot.Visited,
                    previouslyVisited: snapshot.PreviouslyVisited);
                vm.LatestTreeAscii = path;

                var fallbackPath = Display.AsciiTree(
                    fallbackTree,
                    showOnlyVisited: true,
                    visited: snapshot.Visited,
                    previouslyVisited: snapshot.PreviouslyVisited);
                vm.LatestFallbackTreeAscii = fallbackPath;

                Sleep(35, ct);
            }
        }
        catch (OperationCanceledException)
        {
            // 暂停即取消，下次启动重新 Build 复位行为状态
        }
        finally
        {
            // 暂停/结束时隐藏浮窗，下次启动由 Start 重新显示
            AutoComboTreeWindowService.Instance.Hide();

            // 停止 E 技能识别结果显示并清除残留绘制内容
            ESkillClassifyViewModel.Instance.PropertyChanged -= OnESkillClassifyResultChanged;
            RemoveESkillClassifyDrawables();

            // 暂停/结束时先停止索敌与 CD 遮罩循环并等待其完成清理，避免与后续收尾操作冲突
            if (targetingTask != null)
            {
                await targetingCts.CancelAsync();
                try { await targetingTask; } catch (OperationCanceledException) { }
            }

            await overlayCts.CancelAsync();
            try { await overlayTask; } catch (OperationCanceledException) { }
            // 清除全队 CD 遮罩文字，避免任务暂停/结束后残留，并恢复 SkillCd 触发器
            TeamSkillCdOverlay.Clear(_drawingBoard);
            SkillCdTrigger.Resume();

            combatScenes.AfterTask();

            Logger.LogInformation("{Name}任务暂停，可再次点击继续", Name);
        }
    }

    /// <summary>
    /// E 技能识别结果显示：将最新的分类结果（就绪/冷却/未知 + 编号）绘制到遮罩 E 技能图标上方，
    /// 是否可见仍由 MaskWindow 渲染时的"显示识别结果"开关统一过滤
    /// </summary>
    private void OnESkillClassifyResultChanged(object? sender, PropertyChangedEventArgs e)
    {
        if (e.PropertyName != nameof(ESkillClassifyViewModel.Result))
        {
            return;
        }

        var result = ESkillClassifyViewModel.Instance.Result;
        if (result == null)
        {
            RemoveESkillClassifyDrawables();
            return;
        }

        var stateText = result.State switch
        {
            SkillCdState.Ready => "就绪",
            SkillCdState.Cooldown => "冷却",
            _ => "未知",
        };

        if (!string.IsNullOrEmpty(result.Code))
        {
            stateText += $"({result.Code})";
        }

        var textColor = GetElementColor(result.AvatarName);

        // 坐标（ClassifyRect/TextPosition）已由 Avatar 换算到捕获像素域，直接绘制
        _drawingBoard.Set("ESkillClassifyRegion",
            new MaskWindowDrawingRect(result.ClassifyRect, MaskWindowDrawingStroke.FromPen(System.Drawing.Pens.White)));
        _drawingBoard.Set("ESkillClassify",
            new MaskWindowDrawingText(stateText, result.TextPosition, new MaskWindowDrawingTextStyle(textColor)));
    }

    /// <summary>
    /// 根据角色名经 AvatarProfiles 推导元素颜色，无档案或非元素标签时回退默认识别文本色
    /// </summary>
    private static System.Windows.Media.Color GetElementColor(string? avatarName)
    {
        var defaultColor = (System.Windows.Media.Color)ColorConverter.ConvertFromString(
            TaskContext.Instance().Config.MaskWindowConfig.RecognitionTextColor);
        if (string.IsNullOrEmpty(avatarName))
        {
            return defaultColor;
        }

        var profile = AvatarProfiles.TryGet(avatarName);
        var elementTag = profile?.Tags.FirstOrDefault(t => t.EndsWith("元素", StringComparison.Ordinal));
        return elementTag switch
        {
            "火元素" => System.Windows.Media.Color.FromRgb(0xFF, 0x57, 0x49),
            "水元素" => System.Windows.Media.Color.FromRgb(0x33, 0xA6, 0xFF),
            "风元素" => System.Windows.Media.Color.FromRgb(0x3F, 0xCE, 0xC0),
            "雷元素" => System.Windows.Media.Color.FromRgb(0xB3, 0x80, 0xFF),
            "草元素" => System.Windows.Media.Color.FromRgb(0x9A, 0xD9, 0x36),
            "冰元素" => System.Windows.Media.Color.FromRgb(0x7A, 0xF2, 0xF2),
            "岩元素" => System.Windows.Media.Color.FromRgb(0xFF, 0xB5, 0x3A),
            _ => defaultColor,
        };
    }

    private void RemoveESkillClassifyDrawables()
    {
        _drawingBoard.Clear("ESkillClassify");
        _drawingBoard.Clear("ESkillClassifyRegion");
    }
}

/// <summary>
/// 战斗结束检测行为：直接复用 AutoFight 的 CheckFightFinish
/// 战斗结束时抛出 NormalEndException 终止任务
/// 节流周期取自动战斗配置的 CheckTime ，与 AutoFightTask 战斗循环的检查间隔语义一致
/// </summary>
public partial class CheckFightFinish : Behaviour
{
    private readonly Avatar[] _avatars;

    /// <summary>上次完整检查时间（静态共享：多个检查节点实例共用同一节流周期）</summary>
    private static DateTime _lastCheckTime = DateTime.MinValue;

    private TaskFightFinishDetectConfig _detectConfig = null!;

    public CheckFightFinish(string name, Avatar[] avatars) : base(name)
    {
        _avatars = avatars;
    }

    protected override void Initialize()
    {
        // 直接取用户自动战斗配置的战斗结束检测设置（不走 AutoFightParam，避免无关的策略路径解析等副作用）
        var c = TaskContext.Instance().Config.AutoFightConfig.FinishDetectConfig;
        var detectConfig = new AutoFightParam.FightFinishDetectConfig
        {
            FastCheckEnabled = c.FastCheckEnabled,
            FastCheckParams = c.FastCheckParams,
            CheckAfterSwitchAvatar = c.CheckAfterSwitchAvatar,
            CheckEndDelay = c.CheckEndDelay,
            BeforeDetectDelay = c.BeforeDetectDelay,
            RotateFindEnemyEnabled = c.RotateFindEnemyEnabled,
            SkipFightEndCheckWhenEnemyVisible = c.SkipFightEndCheckWhenEnemyVisible,
            BlockCheckBeforeBattleSeconds = c.BlockCheckBeforeBattleSeconds,
            PaimonEndCheckEnabled = c.PaimonEndCheckEnabled,
            PaimonEndCheckDelay = c.PaimonEndCheckDelay,
        };
        _detectConfig = new AutoFightTask.TaskFightFinishDetectConfig(detectConfig);
    }

    protected async override Task<Status> Update()
    {
        // 节流：未到 CheckTime 间隔直接视为未结束，避免树的高频 Tick 反复打开编队界面
        if ((DateTime.Now - _lastCheckTime).TotalSeconds < _detectConfig.CheckTime)
        {
            return Status.Success;
        }

        _lastCheckTime = DateTime.Now;

        // 令牌与其他行为节点保持同源（BeforeTask 写入 Avatar.Ct 的那个）
        var avatar = _avatars.FirstOrDefault();
        var ct = avatar?.Ct ?? CancellationToken.None;
        if (await AutoFightTask.CheckFightFinish(_detectConfig, ct))
        {
            Logger.LogInformation("战斗结束检测确认战斗结束");
            throw new NormalEndException("战斗结束");
        }

        return Status.Success;
    }
}

/// <summary>
/// 全队 E 技能 CD 遮罩显示：复用 SkillCd 模块的 <see cref="SkillCdOverlayRenderer"/>
/// 渲染全队角色的战技 CD 文字（含未知状态"?"），坐标与样式跟随 SkillCdConfig 用户配置
/// CD 由时间戳推算，每次刷新即为当前时刻值，以固定间隔的后台循环形式运行，与行为树 Tick 解耦
/// </summary>
public static class TeamSkillCdOverlay
{
    /// <summary>遮罩文字分组名：与 SkillCd 共用（AutoCombo 运行期间已通过 SkillCdTrigger.Suspend 接管显示权）</summary>
    private const string OverlayKey = SkillCdTrigger.OverlayKey;

    /// <summary>遮罩文字刷新间隔（毫秒）</summary>
    private const int RefreshIntervalMs = 100;

    /// <summary>持续刷新全队战技 CD 遮罩文字，取消令牌触发后退出</summary>
    public static async Task LoopAsync(IMaskWindowDrawingBoard drawingBoard, CancellationToken ct, CombatScenes combatScenes)
    {
        while (!ct.IsCancellationRequested)
        {
            var avatars = combatScenes.GetAvatars();
            var slotCds = new double?[4];
            for (int i = 0; i < slotCds.Length && i < avatars.Count; i++)
            {
                // GetSkillCdSecondsV2：>0 冷却中 / 0 就绪（不绘制）/ null 未知（NaN → "?"）
                var seconds = avatars[i].GetSkillCdSecondsV2();
                slotCds[i] = seconds == null ? double.NaN : (seconds.Value > 0 ? seconds.Value : null);
            }

            SkillCdOverlayRenderer.Update(drawingBoard, OverlayKey, slotCds);

            await Task.Delay(RefreshIntervalMs, ct);
        }
    }

    /// <summary>清除此循环提交的遮罩文字（任务收尾时调用）</summary>
    public static void Clear(IMaskWindowDrawingBoard drawingBoard)
    {
        drawingBoard.Clear(OverlayKey);
    }
}
